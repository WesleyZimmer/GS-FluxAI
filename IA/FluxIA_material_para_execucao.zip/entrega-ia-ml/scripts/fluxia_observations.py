"""Topological signal neighborhoods and shared SUMO traffic observations.

The topology is derived from lane-level SUMO connections, never from Euclidean
distance. Lane changes between adjacent passenger lanes on the same directed
edge are represented as *possible* paths and marked as assumptions.
"""

from __future__ import annotations

import hashlib
import heapq
import json
import math
import argparse
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_C2_DIR = ROOT / "sumo" / "scenarios" / "fluxia_stage6_c2"
DEFAULT_NETWORK = DEFAULT_C2_DIR / "centro_fluxia_c2.net.xml"
DEFAULT_CATALOG = DEFAULT_C2_DIR / "pilot_signals_211_c2.json"
DEFAULT_HORIZON_SECONDS = 30.0
DEFAULT_STORAGE_SPACING_M = 7.5
DEFAULT_SATURATION_FLOW_VEH_PER_LANE_S = 0.5
MAX_DOWNSTREAM_EDGES = 30
MAX_SEARCH_STATES_PER_MOVEMENT = 5000


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def normalize_occupancy_fraction(raw_value: object) -> float:
    """Return SUMO TraCI lane occupancy as a bounded 0..1 fraction.

    TraCI already reports occupied vehicle length divided by lane length. It is
    not a percentage; the local Python binding docstring is misleading here.
    """
    try:
        value = float(raw_value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Ocupação TraCI inválida: {raw_value!r}") from exc
    if not math.isfinite(value):
        raise ValueError(f"Ocupação TraCI não finita: {raw_value!r}")
    return max(0.0, min(1.0, value))


def lane_allows_passenger(lane: ET.Element) -> bool:
    allow = set(lane.get("allow", "").split())
    disallow = set(lane.get("disallow", "").split())
    if allow:
        return "passenger" in allow or "all" in allow
    return "passenger" not in disallow and "all" not in disallow


def _stable_id(prefix: str, *parts: object) -> str:
    raw = "|".join(str(part) for part in parts)
    return f"{prefix}_{hashlib.sha1(raw.encode('utf-8')).hexdigest()[:14]}"


@dataclass(frozen=True)
class LaneInfo:
    lane_id: str
    edge_id: str
    index: int
    length_m: float
    speed_limit_mps: float
    passenger_allowed: bool


@dataclass(frozen=True)
class Connection:
    from_edge: str
    to_edge: str
    from_lane_id: str
    to_lane_id: str
    via: str | None
    tls_id: str | None
    link_index: int | None
    direction: str | None
    state: str | None


class SignalTopology:
    """Lane-resolved controller movements and paths to the first next signal."""

    def __init__(self, network_path: Path, catalog_path: Path) -> None:
        self.network_path = network_path.resolve()
        self.catalog_path = catalog_path.resolve()
        root = ET.parse(self.network_path).getroot()

        self.edges: dict[str, dict[str, Any]] = {}
        self.lanes: dict[str, LaneInfo] = {}
        self.lanes_by_edge: dict[str, list[str]] = defaultdict(list)
        self._lane_by_edge_index: dict[tuple[str, int], str] = {}
        self._lane_node_ids: dict[str, tuple[str | None, str | None]] = {}
        for edge in root.findall("edge"):
            edge_id = edge.get("id", "")
            lane_ids: list[str] = []
            for lane in edge.findall("lane"):
                lane_id = lane.get("id")
                if not lane_id:
                    continue
                index = int(lane.get("index", "0"))
                info = LaneInfo(
                    lane_id=lane_id,
                    edge_id=edge_id,
                    index=index,
                    length_m=float(lane.get("length", "0")),
                    speed_limit_mps=float(lane.get("speed", "0")),
                    passenger_allowed=lane_allows_passenger(lane),
                )
                self.lanes[lane_id] = info
                lane_ids.append(lane_id)
                self._lane_by_edge_index[(edge_id, index)] = lane_id
                self._lane_node_ids[lane_id] = (edge.get("from"), edge.get("to"))
            self.edges[edge_id] = {
                "edge_id": edge_id,
                "from_node": edge.get("from"),
                "to_node": edge.get("to"),
                "name": edge.get("name", ""),
                "function": edge.get("function", "road"),
                "internal": edge.get("function") == "internal" or edge_id.startswith(":"),
                "lane_ids": sorted(lane_ids, key=lambda lane_id: self.lanes[lane_id].index),
                "length_m": max((self.lanes[lane_id].length_m for lane_id in lane_ids), default=0.0),
                "passenger_lane_count": sum(self.lanes[lane_id].passenger_allowed for lane_id in lane_ids),
            }
            self.lanes_by_edge[edge_id] = sorted(lane_ids, key=lambda lane_id: self.lanes[lane_id].index)

        catalog = json.loads(self.catalog_path.read_text(encoding="utf-8"))
        self.signal_catalog = {str(row["controller_id"]): row for row in catalog.get("signals", [])}
        self.tls_ids = sorted(self.signal_catalog)
        self.tls_by_id = {tls.get("id", ""): tls for tls in root.findall("tlLogic")}

        self.connections: list[Connection] = []
        self.outgoing_by_lane: dict[str, list[Connection]] = defaultdict(list)
        self.controlled_by_link: dict[tuple[str, int], list[Connection]] = defaultdict(list)
        passenger_connections = 0
        controlled_connections = 0
        unknown_tls_ids: set[str] = set()
        for raw in root.findall("connection"):
            from_edge = raw.get("from", "")
            to_edge = raw.get("to", "")
            from_index = int(raw.get("fromLane", "0"))
            to_index = int(raw.get("toLane", "0"))
            from_lane = self._lane_by_edge_index.get((from_edge, from_index))
            to_lane = self._lane_by_edge_index.get((to_edge, to_index))
            if from_lane is None or to_lane is None:
                continue
            if not self.lanes[from_lane].passenger_allowed or not self.lanes[to_lane].passenger_allowed:
                continue
            tls_id = raw.get("tl")
            link_index = int(raw.get("linkIndex")) if raw.get("linkIndex") is not None else None
            connection = Connection(
                from_edge=from_edge,
                to_edge=to_edge,
                from_lane_id=from_lane,
                to_lane_id=to_lane,
                via=raw.get("via"),
                tls_id=tls_id,
                link_index=link_index,
                direction=raw.get("dir"),
                state=raw.get("state"),
            )
            self.connections.append(connection)
            self.outgoing_by_lane[from_lane].append(connection)
            passenger_connections += 1
            if tls_id and link_index is not None:
                controlled_connections += 1
                self.controlled_by_link[(tls_id, link_index)].append(connection)
                if tls_id not in self.signal_catalog:
                    unknown_tls_ids.add(tls_id)

        for lane_id in self.outgoing_by_lane:
            self.outgoing_by_lane[lane_id].sort(
                key=lambda item: (item.to_edge, item.to_lane_id, item.tls_id or "", item.link_index or -1)
            )

        self.movements: list[dict[str, Any]] = []
        self.movements_by_tls: dict[str, list[dict[str, Any]]] = defaultdict(list)
        self.movements_by_link: dict[tuple[str, int], list[dict[str, Any]]] = defaultdict(list)
        self._downstream_cache: dict[tuple[str, str], tuple[list[dict[str, Any]], dict[str, int]]] = {}
        for (tls_id, link_index), controlled in sorted(self.controlled_by_link.items()):
            for connection in controlled:
                movement_id = _stable_id(
                    "mv", tls_id, link_index, connection.from_lane_id, connection.to_lane_id
                )
                paths, outcomes = self._find_first_downstream_signals(
                    connection.to_lane_id, origin_tls_id=tls_id
                )
                movement = {
                    "movement_id": movement_id,
                    "upstream_signal_id": tls_id,
                    "link_index": link_index,
                    "from_edge_id": connection.from_edge,
                    "from_lane_id": connection.from_lane_id,
                    "to_edge_id": connection.to_edge,
                    "to_lane_id": connection.to_lane_id,
                    "via_internal_lane_id": connection.via,
                    "direction": connection.direction,
                    "connection_state": connection.state,
                    "receiver_edge_id": connection.to_edge,
                    "downstream_options": paths,
                    "search_outcomes": outcomes,
                    "no_next_signal": not bool(paths),
                }
                self.movements.append(movement)
                self.movements_by_tls[tls_id].append(movement)
                self.movements_by_link[(tls_id, link_index)].append(movement)

        for rows in self.movements_by_tls.values():
            rows.sort(key=lambda row: (row["link_index"], row["from_lane_id"], row["to_lane_id"]))

        self.segment_consumers_by_edge: dict[str, set[str]] = defaultdict(set)
        self.observation_lane_ids: set[str] = set()
        for movement in self.movements:
            self.observation_lane_ids.add(movement["from_lane_id"])
            self.observation_lane_ids.add(movement["to_lane_id"])
            self.segment_consumers_by_edge[movement["receiver_edge_id"]].add(movement["upstream_signal_id"])
            for option in movement["downstream_options"]:
                for edge_id in option["segment_edge_ids"]:
                    self.segment_consumers_by_edge[edge_id].add(movement["upstream_signal_id"])
                    self.observation_lane_ids.update(self.edges[edge_id]["lane_ids"])
                self.observation_lane_ids.add(option["terminal_from_lane_id"])
                self.observation_lane_ids.add(option["terminal_to_lane_id"])

        self.passenger_connection_count = passenger_connections
        self.controlled_connection_count = controlled_connections
        self.unknown_tls_ids = sorted(unknown_tls_ids)

    def _lane_change_neighbors(self, lane_id: str) -> list[str]:
        info = self.lanes[lane_id]
        lane_ids = self.lanes_by_edge[info.edge_id]
        return [
            candidate
            for candidate in lane_ids
            if self.lanes[candidate].passenger_allowed
            and abs(self.lanes[candidate].index - info.index) == 1
        ]

    def _lane_speed(self, lane_id: str) -> float:
        return max(0.1, self.lanes[lane_id].speed_limit_mps)

    def _find_first_downstream_signals(
        self, start_lane_id: str, origin_tls_id: str
    ) -> tuple[list[dict[str, Any]], dict[str, int]]:
        cache_key = (start_lane_id, origin_tls_id)
        if cache_key in self._downstream_cache:
            return self._downstream_cache[cache_key]

        first_edge = self.lanes[start_lane_id].edge_id
        first_edge_info = self.edges[first_edge]
        start_cost = first_edge_info["length_m"] / self._lane_speed(start_lane_id)
        serial = 0
        heap: list[tuple[float, int, dict[str, Any]]] = []
        initial = {
            "lane_id": start_lane_id,
            "edge_ids": [first_edge],
            "lane_ids": [start_lane_id],
            "lane_changes": [],
            "distance_m": first_edge_info["length_m"],
            "visited_edges": {first_edge},
            "depth": 1,
        }
        heapq.heappush(heap, (start_cost, serial, initial))
        best_cost = {start_lane_id: start_cost}
        best_paths: dict[tuple[str, int, str, str], dict[str, Any]] = {}
        outcome_counts: Counter[str] = Counter()
        explored = 0

        def push(lane_id: str, state: dict[str, Any], cost: float) -> None:
            nonlocal serial
            if cost + 1e-9 >= best_cost.get(lane_id, math.inf):
                return
            best_cost[lane_id] = cost
            serial += 1
            heapq.heappush(heap, (cost, serial, state))

        while heap:
            cost, _, state = heapq.heappop(heap)
            lane_id = state["lane_id"]
            if cost > best_cost.get(lane_id, math.inf) + 1e-9:
                continue
            explored += 1
            if explored > MAX_SEARCH_STATES_PER_MOVEMENT:
                outcome_counts["search_state_limit"] += 1
                break
            if state["depth"] > MAX_DOWNSTREAM_EDGES:
                outcome_counts["search_depth_limit"] += 1
                continue

            expanded_lane_change = False
            for neighbor_lane_id in self._lane_change_neighbors(lane_id):
                neighbor_edge = self.lanes[neighbor_lane_id].edge_id
                if neighbor_edge != self.lanes[lane_id].edge_id:
                    continue
                new_state = {
                    **state,
                    "lane_id": neighbor_lane_id,
                    "lane_ids": [*state["lane_ids"][:-1], neighbor_lane_id],
                    "lane_changes": [
                        *state["lane_changes"],
                        {"edge_id": neighbor_edge, "from_lane_id": lane_id, "to_lane_id": neighbor_lane_id},
                    ],
                }
                push(neighbor_lane_id, new_state, cost)
                expanded_lane_change = True

            outgoing = self.outgoing_by_lane.get(lane_id, [])
            if not outgoing and not expanded_lane_change:
                node = self._lane_node_ids[lane_id][1]
                has_road_outgoing = any(
                    edge.get("from_node") == node
                    and not edge.get("internal")
                    and edge.get("passenger_lane_count", 0) > 0
                    for edge in self.edges.values()
                )
                outcome_counts["dead_end" if has_road_outgoing else "network_boundary"] += 1
                continue

            for connection in outgoing:
                if connection.tls_id and connection.tls_id != origin_tls_id:
                    key = (
                        connection.tls_id,
                        int(connection.link_index if connection.link_index is not None else -1),
                        connection.from_lane_id,
                        connection.to_lane_id,
                    )
                    option = {
                        "path_id": _stable_id("path", start_lane_id, *key, *state["edge_ids"]),
                        "next_signal_id": connection.tls_id,
                        "terminal_link_index": connection.link_index,
                        "terminal_from_edge_id": connection.from_edge,
                        "terminal_from_lane_id": connection.from_lane_id,
                        "terminal_to_edge_id": connection.to_edge,
                        "terminal_to_lane_id": connection.to_lane_id,
                        "segment_edge_ids": list(state["edge_ids"]),
                        "lane_ids_on_path": list(state["lane_ids"]),
                        "lane_changes_assumed": list(state["lane_changes"]),
                        "lane_change_note": (
                            "Mudanças entre faixas adjacentes da mesma aresta são possibilidades topológicas; "
                            "lacunas, regras de faixa e decisão do modelo de troca de faixa do SUMO não foram simuladas nesta busca."
                        ),
                        "distance_m": round(float(state["distance_m"]), 3),
                        "freeflow_travel_time_s": round(float(cost), 3),
                        "search_method": "directed passenger-lane graph; stop at first downstream tls movement",
                    }
                    previous = best_paths.get(key)
                    if previous is None or (cost, len(state["lane_changes"])) < (
                        previous["freeflow_travel_time_s"], len(previous["lane_changes_assumed"])
                    ):
                        best_paths[key] = option
                    outcome_counts["reached_next_signal"] += 1
                    continue
                if connection.tls_id == origin_tls_id:
                    outcome_counts["returned_to_origin_signal"] += 1
                    continue
                target_edge = connection.to_edge
                if target_edge in state["visited_edges"]:
                    outcome_counts["cycle_before_next_signal"] += 1
                    continue
                target_edge_info = self.edges[target_edge]
                target_length = target_edge_info["length_m"]
                target_speed = self._lane_speed(connection.to_lane_id)
                new_state = {
                    "lane_id": connection.to_lane_id,
                    "edge_ids": [*state["edge_ids"], target_edge],
                    "lane_ids": [*state["lane_ids"], connection.to_lane_id],
                    "lane_changes": list(state["lane_changes"]),
                    "distance_m": state["distance_m"] + target_length,
                    "visited_edges": {*state["visited_edges"], target_edge},
                    "depth": state["depth"] + 1,
                }
                push(connection.to_lane_id, new_state, cost + target_length / target_speed)

        options = sorted(
            best_paths.values(),
            key=lambda item: (
                item["freeflow_travel_time_s"],
                item["next_signal_id"],
                int(item["terminal_link_index"] or 0),
                item["terminal_from_lane_id"],
            ),
        )
        outcome_counts["search_states_explored"] = explored
        result = (options, dict(outcome_counts))
        self._downstream_cache[cache_key] = result
        return result

    def to_json(self) -> dict[str, Any]:
        movement_options = sum(len(row["downstream_options"]) for row in self.movements)
        return {
            "schema_version": 1,
            "network_file": str(self.network_path),
            "network_sha256": sha256_file(self.network_path),
            "catalog_file": str(self.catalog_path),
            "catalog_sha256": sha256_file(self.catalog_path),
            "observation_module_sha256": sha256_file(Path(__file__).resolve()),
            "controllers": [
                {
                    "signal_id": tls_id,
                    "catalog_adaptive_control": bool(self.signal_catalog[tls_id].get("adaptive_control", False)),
                    "catalog_x_m": self.signal_catalog[tls_id].get("x"),
                    "catalog_y_m": self.signal_catalog[tls_id].get("y"),
                }
                for tls_id in self.tls_ids
            ],
            "summary": {
                "controller_count": len(self.tls_ids),
                "controlled_connection_count": self.controlled_connection_count,
                "passenger_connection_count": self.passenger_connection_count,
                "controlled_movement_rows": len(self.movements),
                "downstream_path_options": movement_options,
                "movement_rows_without_next_signal": sum(row["no_next_signal"] for row in self.movements),
                "observation_lane_count": len(self.observation_lane_ids),
                "unknown_network_tls_ids": self.unknown_tls_ids,
                "lane_change_method": "adjacent passenger lanes on the same directed edge are explored and explicitly marked as assumed",
            },
            "measurement_contract": {
                "source": "SUMO TraCI lane and traffic-light subscriptions",
                "sampled_once_per_simulation_time": True,
                "shared_state_key": "edge_id within one immutable snapshot",
                "occupancy": "SUMO lane last-step occupancy converted from percent to fraction 0..1; lane-weighted mean on an edge",
                "queue": "SUMO last-step halting vehicle count; separate from occupancy and vehicle count",
                "storage_capacity": "estimated vehicle-equivalents from lane length / configurable nominal spacing; not an observed capacity",
                "mean_speed": "SUMO last-step mean speed in m/s; vehicle-count weighted on an edge",
                "phase_age": "seconds elapsed in the current programmed phase, estimated as configured duration minus TraCI next-switch remainder",
                "measurement_age": "seconds since the snapshot was sampled; increases if a snapshot is reused",
                "prediction": "current corridor stock + estimated upstream entries - estimated downstream discharges over a finite horizon",
                "yellow_handling": "vehicles on a route-matched approach that can reach the stop line before the current yellow expires are counted as committed yellow flow",
                "assumptions": [
                    "Lane changes are potential adjacency links, not a calibrated lane-changing simulation.",
                    "Traffic-light program durations and phases are forecasts from the currently selected SUMO program, not verified CET timing plans.",
                    "Saturation discharge flow is a configurable synthetic rate.",
                    "Recent measured inflow is extrapolated only as an initial transparent baseline.",
                ],
            },
            "movements": self.movements,
            "shared_edge_consumers": {
                edge_id: sorted(signal_ids)
                for edge_id, signal_ids in sorted(self.segment_consumers_by_edge.items())
            },
        }


class ObservationService:
    """Sample lane/TLS telemetry once per timestep and share immutable edge states."""

    def __init__(
        self,
        topology: SignalTopology,
        connection: Any,
        *,
        horizon_seconds: float = DEFAULT_HORIZON_SECONDS,
        storage_spacing_m: float = DEFAULT_STORAGE_SPACING_M,
        saturation_flow_veh_per_lane_s: float = DEFAULT_SATURATION_FLOW_VEH_PER_LANE_S,
        active_signal_ids: set[str] | None = None,
        flow_window_seconds: float = 60.0,
    ) -> None:
        import traci.constants as tc

        if horizon_seconds <= 0 or storage_spacing_m <= 0 or saturation_flow_veh_per_lane_s <= 0:
            raise ValueError("Horizon, espaço de armazenamento e vazão de saturação precisam ser positivos.")
        self.topology = topology
        self.connection = connection
        self.horizon_seconds = float(horizon_seconds)
        self.storage_spacing_m = float(storage_spacing_m)
        self.saturation_flow_veh_per_lane_s = float(saturation_flow_veh_per_lane_s)
        self.flow_window_seconds = float(flow_window_seconds)
        self.active_signal_ids = set(active_signal_ids) if active_signal_ids else set(topology.tls_ids)
        self.active_signal_ids.intersection_update(topology.tls_ids)
        self._last_snapshot: dict[str, Any] | None = None
        self._last_time: float | None = None
        self._previous_edge_vehicle_ids: dict[str, set[str]] = {}
        self._edge_arrival_history: dict[tuple[str, str], deque[tuple[float, int]]] = defaultdict(deque)
        self.sample_request_count = 0
        self.unique_sample_count = 0
        self.duplicate_sample_request_count = 0
        self.lane_subscription_count = 0
        self.tls_subscription_count = 0
        self._tc = tc

        active_movements = [
            movement
            for tls_id in self.active_signal_ids
            for movement in topology.movements_by_tls.get(tls_id, [])
        ]
        self.sensor_edge_ids: set[str] = set()
        for movement in active_movements:
            self.sensor_edge_ids.add(movement["from_edge_id"])
            self.sensor_edge_ids.add(movement["to_edge_id"])
            for option in movement["downstream_options"]:
                self.sensor_edge_ids.update(option["segment_edge_ids"])
                self.sensor_edge_ids.add(option["terminal_from_edge_id"])
                self.sensor_edge_ids.add(option["terminal_to_edge_id"])
        self.sensor_lane_ids = {
            lane_id
            for edge_id in self.sensor_edge_ids
            for lane_id in topology.edges[edge_id]["lane_ids"]
        }
        self.sensor_lane_ids.update(movement["from_lane_id"] for movement in active_movements)
        self.sensor_lane_ids.update(movement["to_lane_id"] for movement in active_movements)
        for movement in active_movements:
            for option in movement["downstream_options"]:
                self.sensor_lane_ids.add(option["terminal_from_lane_id"])
                self.sensor_lane_ids.add(option["terminal_to_lane_id"])

        lane_variables = [
            tc.LAST_STEP_VEHICLE_NUMBER,
            tc.LAST_STEP_VEHICLE_HALTING_NUMBER,
            tc.LAST_STEP_MEAN_SPEED,
            tc.LAST_STEP_OCCUPANCY,
            tc.LAST_STEP_VEHICLE_ID_LIST,
        ]
        for lane_id in sorted(self.sensor_lane_ids):
            self.connection.lane.subscribe(lane_id, lane_variables)
            self.lane_subscription_count += 1
        tls_variables = [
            tc.TL_CURRENT_PHASE,
            tc.TL_CURRENT_PROGRAM,
            tc.TL_NEXT_SWITCH,
            tc.TL_RED_YELLOW_GREEN_STATE,
            tc.TL_SPENT_DURATION,
        ]
        for tls_id in sorted(self.active_signal_ids):
            self.connection.trafficlight.subscribe(tls_id, tls_variables)
            self.tls_subscription_count += 1
        self._program_logics: dict[str, dict[str, Any]] = {}
        for tls_id in sorted(self.active_signal_ids):
            self._program_logics[tls_id] = {
                logic.programID: logic
                for logic in self.connection.trafficlight.getAllProgramLogics(tls_id)
            }

    @staticmethod
    def _vehicle_matches(vehicle: dict[str, Any], from_edge: str, to_edge: str) -> bool:
        route = vehicle.get("route", ())
        index = int(vehicle.get("route_index", -1))
        return (
            0 <= index < len(route) - 1
            and route[index] == from_edge
            and route[index + 1] == to_edge
        )

    def _tls_samples(self, now: float) -> dict[str, dict[str, Any]]:
        tc = self._tc
        results = self.connection.trafficlight.getAllSubscriptionResults() or {}
        samples: dict[str, dict[str, Any]] = {}
        for tls_id in self.active_signal_ids:
            row = results.get(tls_id)
            if row is None:
                continue
            phase_index = int(row.get(tc.TL_CURRENT_PHASE, 0))
            program_id = str(row.get(tc.TL_CURRENT_PROGRAM, ""))
            next_switch = float(row.get(tc.TL_NEXT_SWITCH, now))
            signal_state = str(row.get(tc.TL_RED_YELLOW_GREEN_STATE, ""))
            logic = self._program_logics.get(tls_id, {}).get(program_id)
            phase_duration = 0.0
            if logic is not None and 0 <= phase_index < len(logic.phases):
                phase_duration = float(logic.phases[phase_index].duration)
            remaining = max(0.0, next_switch - now)
            # TL_SPENT_DURATION is maintained by SUMO when TraCI overrides the
            # current phase duration.  Subtracting remaining time from the
            # nominal duration makes the reported age collapse after an
            # extension (e.g. nominal 24 s, age 10 s, remaining 80 s).
            phase_age = max(0.0, float(row.get(tc.TL_SPENT_DURATION, 0.0)))
            samples[tls_id] = {
                "signal_id": tls_id,
                "program_id": program_id,
                "phase_index": phase_index,
                "phase_state": signal_state,
                "phase_duration_s": phase_duration,
                "phase_remaining_s": remaining,
                "phase_age_s": phase_age,
                "phase_effective_duration_s": phase_age + remaining,
                "phase_age_source": "TraCI TL_SPENT_DURATION",
                "next_switch_time_s": next_switch,
                "measurement_time_s": now,
                "measurement_age_s": 0.0,
                "source": "TraCI traffic-light subscription",
            }
        return samples

    def _phase_service_seconds(
        self,
        tls_id: str,
        link_index: int,
        horizon: float,
        tls_sample: dict[str, Any],
    ) -> tuple[float, float, float]:
        if horizon <= 0:
            return 0.0, 0.0, float(horizon)
        program_id = tls_sample["program_id"]
        logic = self._program_logics.get(tls_id, {}).get(program_id)
        if logic is None or not logic.phases:
            return 0.0, 0.0, float(horizon)
        phase_index = int(tls_sample["phase_index"])
        if phase_index < 0 or phase_index >= len(logic.phases):
            return 0.0, 0.0, float(horizon)

        green_seconds = 0.0
        yellow_seconds = 0.0
        red_seconds = 0.0
        remaining_horizon = float(horizon)
        current_index = phase_index
        first_phase = True
        max_iterations = max(100, int(horizon / 0.1) + len(logic.phases) * 2)
        iterations = 0
        while remaining_horizon > 1e-9 and iterations < max_iterations:
            iterations += 1
            phase = logic.phases[current_index]
            duration = float(tls_sample["phase_remaining_s"]) if first_phase else float(phase.duration)
            if duration <= 1e-9:
                duration = float(phase.duration)
            chunk = min(duration, remaining_horizon)
            state = str(phase.state)
            char = state[link_index] if 0 <= link_index < len(state) else "r"
            if char in {"G", "g"}:
                green_seconds += chunk
            elif char in {"y", "Y"}:
                yellow_seconds += chunk
            else:
                red_seconds += chunk
            remaining_horizon -= chunk
            first_phase = False
            next_phases = tuple(getattr(phase, "next", ()) or ())
            current_index = int(next_phases[0]) if next_phases else (current_index + 1) % len(logic.phases)
            current_index %= len(logic.phases)
        if remaining_horizon > 1e-9:
            red_seconds += remaining_horizon
        return green_seconds, yellow_seconds, red_seconds

    def _vehicle_profiles(self, lane_states: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
        ids = sorted({vehicle_id for row in lane_states.values() for vehicle_id in row["vehicle_ids"]})
        profiles: dict[str, dict[str, Any]] = {}
        for vehicle_id in ids:
            try:
                route = tuple(self.connection.vehicle.getRoute(vehicle_id))
                lane_id = str(self.connection.vehicle.getLaneID(vehicle_id))
                profiles[vehicle_id] = {
                    "vehicle_id": vehicle_id,
                    "route": route,
                    "route_index": int(self.connection.vehicle.getRouteIndex(vehicle_id)),
                    "lane_id": lane_id,
                    "lane_position_m": float(self.connection.vehicle.getLanePosition(vehicle_id)),
                    "speed_mps": max(0.0, float(self.connection.vehicle.getSpeed(vehicle_id))),
                    "length_m": max(0.0, float(self.connection.vehicle.getLength(vehicle_id))),
                }
            except Exception:
                # Vehicle may leave the network between the lane subscription and this lookup.
                continue
        return profiles

    def sample(self, now: float | None = None) -> dict[str, Any]:
        self.sample_request_count += 1
        if now is None:
            now = float(self.connection.simulation.getTime())
        now = float(now)
        if self._last_snapshot is not None and self._last_time is not None and math.isclose(now, self._last_time, abs_tol=1e-9):
            self.duplicate_sample_request_count += 1
            return self._last_snapshot

        lane_results = self.connection.lane.getAllSubscriptionResults() or {}
        tc = self._tc
        lane_states: dict[str, dict[str, Any]] = {}
        edge_vehicle_ids: dict[str, set[str]] = defaultdict(set)
        for lane_id in self.sensor_lane_ids:
            row = lane_results.get(lane_id, {})
            lane = self.topology.lanes[lane_id]
            vehicle_ids = list(row.get(tc.LAST_STEP_VEHICLE_ID_LIST, ()))
            lane_states[lane_id] = {
                "lane_id": lane_id,
                "edge_id": lane.edge_id,
                "vehicle_count": int(row.get(tc.LAST_STEP_VEHICLE_NUMBER, len(vehicle_ids))),
                "queue_vehicle_count": int(row.get(tc.LAST_STEP_VEHICLE_HALTING_NUMBER, 0)),
                "mean_speed_mps": float(row.get(tc.LAST_STEP_MEAN_SPEED, 0.0)),
                "occupancy_fraction": normalize_occupancy_fraction(row.get(tc.LAST_STEP_OCCUPANCY, 0.0)),
                "vehicle_ids": vehicle_ids,
                "length_m": lane.length_m,
                "speed_limit_mps": lane.speed_limit_mps,
                "storage_capacity_vehicles_estimate": max(1, int(lane.length_m // self.storage_spacing_m)) if lane.length_m > 0 else 0,
                "measurement_time_s": now,
                "measurement_age_s": 0.0,
                "source": "TraCI lane subscription",
            }
            edge_vehicle_ids[lane.edge_id].update(vehicle_ids)

        vehicle_profiles = self._vehicle_profiles(lane_states)
        interval = None if self._last_time is None else max(1e-9, now - self._last_time)
        pair_entries: Counter[tuple[str, str]] = Counter()
        if interval is not None:
            for edge_id, current_ids in edge_vehicle_ids.items():
                previous_ids = self._previous_edge_vehicle_ids.get(edge_id, set())
                for vehicle_id in current_ids - previous_ids:
                    vehicle = vehicle_profiles.get(vehicle_id)
                    if not vehicle:
                        continue
                    route = vehicle["route"]
                    route_index = int(vehicle["route_index"])
                    if 0 < route_index < len(route) and route[route_index] == edge_id:
                        pair_entries[(route[route_index - 1], route[route_index])] += 1
            for pair, count in pair_entries.items():
                history = self._edge_arrival_history[pair]
                history.append((now, count))
        self._previous_edge_vehicle_ids = {edge: set(ids) for edge, ids in edge_vehicle_ids.items()}
        for history in self._edge_arrival_history.values():
            while history and now - history[0][0] > self.flow_window_seconds:
                history.popleft()

        edge_states: dict[str, dict[str, Any]] = {}
        for edge_id in sorted(self.sensor_edge_ids):
            lane_ids = [lane_id for lane_id in self.topology.edges[edge_id]["lane_ids"] if lane_id in lane_states]
            if not lane_ids:
                continue
            rows = [lane_states[lane_id] for lane_id in lane_ids]
            count = len(edge_vehicle_ids.get(edge_id, set()))
            queue_count = sum(row["queue_vehicle_count"] for row in rows)
            weighted_speed = sum(row["mean_speed_mps"] * row["vehicle_count"] for row in rows)
            speed_denominator = sum(row["vehicle_count"] for row in rows)
            occupancy = sum(row["occupancy_fraction"] for row in rows) / max(1, len(rows))
            capacity = sum(row["storage_capacity_vehicles_estimate"] for row in rows)
            previous_ids = set()
            if interval is not None:
                previous_ids = self._previous_edge_vehicle_ids.get(edge_id, set())
            edge_states[edge_id] = {
                "edge_id": edge_id,
                "road_name": self.topology.edges[edge_id]["name"],
                "vehicle_count": count,
                "queue_vehicle_count": queue_count,
                "mean_speed_mps": weighted_speed / speed_denominator if speed_denominator else None,
                "occupancy_fraction": occupancy,
                "storage_capacity_vehicles_estimate": capacity,
                "storage_used_fraction_estimate": count / capacity if capacity else None,
                "lane_count_observed": len(rows),
                "lane_states": rows,
                "measurement_time_s": now,
                "measurement_age_s": 0.0,
                "source": "aggregate of unique TraCI lane subscriptions",
            }

        tls_states = self._tls_samples(now)
        snapshot = {
            "snapshot_id": f"t{now:.3f}",
            "time_s": now,
            "measurement_age_s": 0.0,
            "source": "SUMO TraCI subscriptions",
            "edge_states": edge_states,
            "lane_states": lane_states,
            "vehicle_profiles": vehicle_profiles,
            "tls_states": tls_states,
            "pair_inflow_rates_vps": {
                f"{from_edge}->{to_edge}": sum(count for _, count in history) / self.flow_window_seconds
                for (from_edge, to_edge), history in self._edge_arrival_history.items()
            },
            "unique_pair_entries_this_sample": {
                f"{from_edge}->{to_edge}": count for (from_edge, to_edge), count in pair_entries.items()
            },
        }
        self.unique_sample_count += 1
        self._last_snapshot = snapshot
        self._last_time = now
        return snapshot

    def _link_phase(self, snapshot: dict[str, Any], tls_id: str, link_index: int, horizon: float) -> dict[str, Any]:
        tls = snapshot["tls_states"].get(tls_id)
        if tls is None:
            return {
                "signal_id": tls_id,
                "link_index": link_index,
                "current_color": None,
                "phase_index": None,
                "phase_age_s": None,
                "phase_remaining_s": None,
                "green_seconds_in_horizon": 0.0,
                "yellow_seconds_in_horizon": 0.0,
                "red_seconds_in_horizon": float(horizon),
                "measurement_age_s": None,
                "observed": False,
                "source": "outside the observed signal subset",
            }
        state = tls["phase_state"]
        color = state[link_index] if 0 <= link_index < len(state) else "r"
        green, yellow, red = self._phase_service_seconds(tls_id, link_index, horizon, tls)
        return {
            "signal_id": tls_id,
            "link_index": link_index,
            "current_color": color,
            "phase_index": tls["phase_index"],
            "phase_age_s": tls["phase_age_s"],
            "phase_remaining_s": tls["phase_remaining_s"],
            "green_seconds_in_horizon": round(green, 3),
            "yellow_seconds_in_horizon": round(yellow, 3),
            "red_seconds_in_horizon": round(red, 3),
            "measurement_age_s": tls["measurement_age_s"],
            "observed": True,
            "source": tls["source"],
        }

    def _matching_approach_vehicles(
        self, snapshot: dict[str, Any], lane_ids: set[str], from_edge: str, to_edge: str
    ) -> list[dict[str, Any]]:
        ids = {
            vehicle_id
            for lane_id in lane_ids
            for vehicle_id in snapshot["lane_states"].get(lane_id, {}).get("vehicle_ids", ())
        }
        return [
            vehicle
            for vehicle_id in ids
            if (vehicle := snapshot["vehicle_profiles"].get(vehicle_id))
            and self._vehicle_matches(vehicle, from_edge, to_edge)
        ]

    def _yellow_committed_count(
        self,
        snapshot: dict[str, Any],
        tls_id: str,
        link_index: int,
        lane_ids: set[str],
        from_edge: str,
        to_edge: str,
    ) -> tuple[int, list[str]]:
        tls = snapshot["tls_states"].get(tls_id)
        if tls is None:
            return 0, []
        color = tls["phase_state"][link_index] if link_index < len(tls["phase_state"]) else "r"
        if color not in {"y", "Y"}:
            return 0, []
        remaining = max(0.0, float(tls["phase_remaining_s"]))
        committed: list[str] = []
        for vehicle in self._matching_approach_vehicles(snapshot, lane_ids, from_edge, to_edge):
            lane = self.topology.lanes.get(vehicle["lane_id"])
            if lane is None:
                continue
            distance_to_stop_m = max(0.0, lane.length_m - float(vehicle["lane_position_m"]))
            speed = float(vehicle["speed_mps"])
            reachable_distance = speed * remaining + min(2.0, float(vehicle["length_m"]) * 0.4)
            if distance_to_stop_m <= reachable_distance:
                committed.append(vehicle["vehicle_id"])
        return len(committed), sorted(committed)

    def forecast_path(
        self,
        movement: dict[str, Any],
        option: dict[str, Any],
        snapshot: dict[str, Any],
        *,
        horizon_seconds: float | None = None,
    ) -> dict[str, Any]:
        horizon = self.horizon_seconds if horizon_seconds is None else float(horizon_seconds)
        path_edges = list(dict.fromkeys(option["segment_edge_ids"]))
        segment_states = [snapshot["edge_states"][edge_id] for edge_id in path_edges if edge_id in snapshot["edge_states"]]
        stock = sum(int(edge["vehicle_count"]) for edge in segment_states)
        storage_capacity = sum(int(edge["storage_capacity_vehicles_estimate"]) for edge in segment_states)
        speeds = [float(edge["mean_speed_mps"]) for edge in segment_states if edge["mean_speed_mps"] and edge["mean_speed_mps"] > 0]
        if speeds:
            travel_speed = sum(speeds) / len(speeds)
        else:
            path_lengths = [self.topology.edges[edge_id]["length_m"] for edge_id in path_edges]
            limits = [
                self.topology.lanes[lane_id].speed_limit_mps
                for edge_id in path_edges
                for lane_id in self.topology.edges[edge_id]["lane_ids"]
                if self.topology.lanes[lane_id].passenger_allowed
                and self.topology.lanes[lane_id].speed_limit_mps > 0
            ]
            travel_speed = min(13.89, sum(limits) / len(limits)) if limits else 5.0
        distance = sum(float(self.topology.edges[edge_id]["length_m"]) for edge_id in path_edges)
        travel_time = distance / max(1.0, travel_speed)
        service_horizon = max(0.0, horizon - travel_time)

        source_link_index = int(movement["link_index"])
        source_tls_id = str(movement["upstream_signal_id"])
        source_lane_ids = {
            row["from_lane_id"]
            for row in self.topology.movements_by_link.get((source_tls_id, source_link_index), [])
            if row["to_edge_id"] == movement["to_edge_id"]
        }
        approach_vehicles = self._matching_approach_vehicles(
            snapshot, source_lane_ids, movement["from_edge_id"], movement["to_edge_id"]
        )
        source_phase = self._link_phase(snapshot, source_tls_id, source_link_index, horizon)
        upstream_yellow_committed, upstream_yellow_ids = self._yellow_committed_count(
            snapshot,
            source_tls_id,
            source_link_index,
            source_lane_ids,
            movement["from_edge_id"],
            movement["to_edge_id"],
        )
        source_lane_count = max(1, len(source_lane_ids))
        expected_recent_arrivals = float(
            snapshot["pair_inflow_rates_vps"].get(
                f"{movement['from_edge_id']}->{movement['to_edge_id']}", 0.0
            )
        ) * horizon
        entry_capacity = (
            self.saturation_flow_veh_per_lane_s
            * source_lane_count
            * source_phase["green_seconds_in_horizon"]
            + upstream_yellow_committed
        )
        expected_inflow = min(len(approach_vehicles) + expected_recent_arrivals, entry_capacity)

        terminal_tls_id = str(option["next_signal_id"])
        terminal_link_index = int(option["terminal_link_index"])
        terminal_from_edge = str(option["terminal_from_edge_id"])
        terminal_to_edge = str(option["terminal_to_edge_id"])
        terminal_lane_ids = {
            row["from_lane_id"]
            for row in self.topology.movements_by_link.get((terminal_tls_id, terminal_link_index), [])
            if row["from_edge_id"] == terminal_from_edge and row["to_edge_id"] == terminal_to_edge
        }
        if not terminal_lane_ids:
            terminal_lane_ids = {str(option["terminal_from_lane_id"])}
        terminal_phase = self._link_phase(snapshot, terminal_tls_id, terminal_link_index, service_horizon)
        downstream_yellow_committed, downstream_yellow_ids = self._yellow_committed_count(
            snapshot,
            terminal_tls_id,
            terminal_link_index,
            terminal_lane_ids,
            terminal_from_edge,
            terminal_to_edge,
        )
        exit_capacity = (
            self.saturation_flow_veh_per_lane_s
            * max(1, len(terminal_lane_ids))
            * terminal_phase["green_seconds_in_horizon"]
            + downstream_yellow_committed
        )
        terminal_observed = bool(terminal_phase.get("observed"))
        expected_outflow = min(stock + expected_inflow, exit_capacity) if terminal_observed else None
        predicted_stock = max(0.0, stock + expected_inflow - expected_outflow) if expected_outflow is not None else None
        current_storage_fraction = stock / storage_capacity if storage_capacity else None
        predicted_storage_fraction = predicted_stock / storage_capacity if storage_capacity and predicted_stock is not None else None
        return {
            "movement_id": movement["movement_id"],
            "path_id": option["path_id"],
            "source_signal_id": source_tls_id,
            "source_link_index": source_link_index,
            "next_signal_id": terminal_tls_id,
            "next_link_index": terminal_link_index,
            "segment_edge_ids": path_edges,
            "source_lane_ids": sorted(source_lane_ids),
            "terminal_lane_ids": sorted(terminal_lane_ids),
            "horizon_seconds": horizon,
            "travel_time_estimate_s": round(travel_time, 3),
            "effective_downstream_horizon_s": round(service_horizon, 3),
            "current_stock_vehicles": stock,
            "estimated_storage_capacity_vehicles": storage_capacity,
            "current_storage_fraction_estimate": round(current_storage_fraction, 6) if current_storage_fraction is not None else None,
            "matched_current_approach_vehicles": len(approach_vehicles),
            "recent_observed_inflow_rate_vps": round(expected_recent_arrivals / horizon, 6) if horizon else 0.0,
            "expected_new_arrivals_from_recent_rate": round(expected_recent_arrivals, 3),
            "upstream_green_seconds": source_phase["green_seconds_in_horizon"],
            "upstream_yellow_seconds": source_phase["yellow_seconds_in_horizon"],
            "upstream_yellow_committed_vehicle_ids": upstream_yellow_ids,
            "expected_inflow_vehicles": round(expected_inflow, 3),
            "downstream_green_seconds": terminal_phase["green_seconds_in_horizon"],
            "downstream_yellow_seconds": terminal_phase["yellow_seconds_in_horizon"],
            "downstream_yellow_committed_vehicle_ids": downstream_yellow_ids,
            "expected_outflow_vehicles": round(expected_outflow, 3) if expected_outflow is not None else None,
            "predicted_stock_vehicles": round(predicted_stock, 3) if predicted_stock is not None else None,
            "predicted_storage_fraction_estimate": round(predicted_storage_fraction, 6) if predicted_storage_fraction is not None else None,
            "sources": {
                "segment_stock": [
                    {"edge_id": edge["edge_id"], "vehicle_count": edge["vehicle_count"], "source": edge["source"]}
                    for edge in segment_states
                ],
                "upstream_phase": source_phase,
                "downstream_phase": terminal_phase,
                "approach_vehicle_routes": [vehicle["vehicle_id"] for vehicle in approach_vehicles],
            },
            "assumptions": {
                "saturation_flow_veh_per_lane_s": self.saturation_flow_veh_per_lane_s,
                "storage_spacing_m_per_vehicle": self.storage_spacing_m,
                "phase_forecast_uses_current_program_nominal_durations": True,
                "new_traffic_beyond_observed_inflow_is_not_generated": True,
                "downstream_signal_outside_observed_subset_invalidates_forecast": True,
                "prediction_is_not_calibrated": True,
            },
        }

    def controller_observation(
        self,
        tls_id: str,
        snapshot: dict[str, Any],
        *,
        include_forecasts: bool = True,
        now_s: float | None = None,
    ) -> dict[str, Any]:
        if tls_id not in self.active_signal_ids:
            raise KeyError(f"Controlador {tls_id} não está ativo neste serviço de observações.")
        current_time = float(self.connection.simulation.getTime()) if now_s is None else float(now_s)
        shared_edges: dict[str, dict[str, Any]] = {}
        movements = []
        for movement in self.topology.movements_by_tls.get(tls_id, []):
            edge_ids = {movement["from_edge_id"], movement["receiver_edge_id"]}
            for option in movement["downstream_options"]:
                edge_ids.update(option["segment_edge_ids"])
            for edge_id in edge_ids:
                edge_state = snapshot["edge_states"].get(edge_id)
                if edge_state is not None:
                    shared_edges[edge_id] = edge_state
            option_rows = []
            for option in movement["downstream_options"]:
                corridor_edges = {
                    edge_id: snapshot["edge_states"][edge_id]
                    for edge_id in option["segment_edge_ids"]
                    if edge_id in snapshot["edge_states"]
                }
                option_row = {
                    **option,
                    "shared_edge_states": corridor_edges,
                }
                if include_forecasts:
                    option_row["forecast"] = self.forecast_path(movement, option, snapshot)
                option_rows.append(option_row)
            movements.append({
                **movement,
                "receiver_edge_state": snapshot["edge_states"].get(movement["receiver_edge_id"]),
                "downstream_options": option_rows,
            })
        tls_state = snapshot["tls_states"].get(tls_id)
        signal_view = None
        if tls_state is not None:
            signal_view = {
                **tls_state,
                "measurement_age_s": max(0.0, current_time - float(tls_state["measurement_time_s"])),
            }
        return {
            "signal_id": tls_id,
            "time_s": current_time,
            "measurement_age_s": max(0.0, current_time - float(snapshot["time_s"])),
            "signal_state": signal_view,
            "shared_edge_states": shared_edges,
            "shared_edge_measurement_ages_s": {
                edge_id: max(0.0, current_time - float(edge_state["measurement_time_s"]))
                for edge_id, edge_state in shared_edges.items()
            },
            "movements": movements,
            "snapshot_id": snapshot["snapshot_id"],
            "source": "shared immutable sample from ObservationService",
        }


def write_topology_map(topology: SignalTopology, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(topology.to_json(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--network", type=Path, default=DEFAULT_NETWORK)
    parser.add_argument("--catalog", type=Path, default=DEFAULT_CATALOG)
    parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_C2_DIR / "topology_map_c2.json",
    )
    args = parser.parse_args()
    topology = SignalTopology(args.network, args.catalog)
    write_topology_map(topology, args.output)
    payload = topology.to_json()["summary"]
    print(json.dumps({"output": str(args.output.resolve()), **payload}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Common SUMO executor for the C4 observation/control integration stage.

This is a diagnostic and comparison harness. It does not train a policy, and
the predictive rule is deliberately labeled experimental and uncalibrated.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
import time
import uuid
import xml.etree.ElementTree as ET
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from statistics import fmean
from typing import Any

import traci

if __package__:
    from .fluxia_observations import ObservationService, SignalTopology
    from .fluxia_cooperative_policy import (
        GreenCandidate,
        choose_green_candidate,
        should_request_yellow,
    )
    from .fluxia_signal_control import (
        DestinationStatus,
        SignalAction,
        controller_from_profile,
        load_timing_profile,
    )
else:
    from fluxia_observations import ObservationService, SignalTopology
    from fluxia_cooperative_policy import (
        GreenCandidate,
        choose_green_candidate,
        should_request_yellow,
    )
    from fluxia_signal_control import (
        DestinationStatus,
        SignalAction,
        controller_from_profile,
        load_timing_profile,
    )


ROOT = Path(__file__).resolve().parents[1]
C2 = ROOT / "sumo" / "scenarios" / "fluxia_stage6_c2"
C3_RUN = ROOT / "docs" / "execucao-luna" / "outputs" / "c3" / "c3_20261117T174942Z"
DEFAULT_NETWORK = C2 / "centro_fluxia_c2.net.xml"
DEFAULT_CATALOG = C2 / "pilot_signals_8_c2.json"
DEFAULT_ROUTES = C3_RUN / "demand_first_hour.rou.xml"
DEFAULT_PROFILE = C2 / "green_timing_profile_c2.json"
DEFAULT_OUTPUT = ROOT / "docs" / "execucao-luna" / "outputs" / "c4"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def discover_sumo(gui: bool) -> Path:
    name = "sumo-gui" if gui else "sumo"
    found = shutil.which(name)
    if found:
        return Path(found).resolve()
    candidate = Path(r"C:\Program Files (x86)\SUMO\bin") / f"{name}.exe"
    if candidate.is_file():
        return candidate.resolve()
    raise FileNotFoundError(f"Não encontrei {name}.exe")


def scheduled_departures(routes: Path) -> list[tuple[float, str]]:
    result = []
    for row in ET.parse(routes).getroot().findall("vehicle"):
        result.append((float(row.get("depart", "0")), row.get("id", "")))
    return result


def edge_fraction(snapshot: dict[str, Any], edge_ids: set[str]) -> tuple[float | None, list[dict[str, Any]]]:
    rows = []
    for edge_id in sorted(edge_ids):
        state = snapshot["edge_states"].get(edge_id)
        if state is None:
            rows.append({"edge_id": edge_id, "missing": True})
            continue
        count = int(state["vehicle_count"])
        capacity = int(state["storage_capacity_vehicles_estimate"])
        fraction = count / capacity if capacity > 0 else None
        rows.append({
            "edge_id": edge_id,
            "road_name": state.get("road_name", ""),
            "vehicle_count": count,
            "capacity_estimate_vehicles": capacity,
            "fraction": fraction,
            "queue_vehicle_count": int(state["queue_vehicle_count"]),
        })
    values = [float(row["fraction"]) for row in rows if isinstance(row.get("fraction"), (int, float))]
    # A stage is as constrained as its most occupied receiving street. Averaging
    # distinct exits could hide one full outlet behind several empty ones.
    return (max(values) if values else None), rows


def actual_path_fraction(snapshot: dict[str, Any], edge_ids: list[str]) -> float | None:
    rows = [snapshot["edge_states"].get(edge_id) for edge_id in dict.fromkeys(edge_ids)]
    rows = [row for row in rows if row is not None]
    if not rows:
        return None
    count = sum(int(row["vehicle_count"]) for row in rows)
    capacity = sum(int(row["storage_capacity_vehicles_estimate"]) for row in rows)
    return min(1.0, count / capacity) if capacity > 0 else None


def actual_path_stock(snapshot: dict[str, Any], edge_ids: list[str]) -> int | None:
    rows = [snapshot["edge_states"].get(edge_id) for edge_id in dict.fromkeys(edge_ids)]
    rows = [row for row in rows if row is not None]
    return sum(int(row["vehicle_count"]) for row in rows) if rows else None


def approach_queue_for_green(
    snapshot: dict[str, Any] | None,
    topology: SignalTopology,
    tls_id: str,
    green_links_for_signal: dict[int, set[int]],
    green_phase: int,
) -> int:
    """Sum unique approach-lane queues controlled by one existing green phase."""
    if snapshot is None:
        return 0
    lane_ids = {
        str(movement["from_lane_id"])
        for link_index in green_links_for_signal[green_phase]
        for movement in topology.movements_by_link.get((tls_id, link_index), [])
    }
    return sum(
        int(snapshot["lane_states"].get(lane_id, {}).get("queue_vehicle_count", 0))
        for lane_id in lane_ids
    )


def parse_xml_if_complete(path: Path) -> tuple[ET.Element | None, str | None]:
    if not path.is_file():
        return None, "file_missing"
    try:
        return ET.parse(path).getroot(), None
    except ET.ParseError as exc:
        return None, f"{type(exc).__name__}: {exc}"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("predictive", "reactive", "cooperative", "native"), default="predictive")
    parser.add_argument("--run-id-prefix", default="c4", help="Prefix for this run's artifact ID.")
    parser.add_argument("--ui", choices=("headless", "gui"), default="headless")
    parser.add_argument("--gui-delay-ms", type=int, default=0,
                        help="Optional SUMO-GUI display delay per simulation step.")
    parser.add_argument("--network", type=Path, default=DEFAULT_NETWORK)
    parser.add_argument("--catalog", type=Path, default=DEFAULT_CATALOG)
    parser.add_argument("--routes", type=Path, default=DEFAULT_ROUTES)
    parser.add_argument("--timing-profile", type=Path, default=DEFAULT_PROFILE)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--end-time", type=float, default=300.0)
    parser.add_argument("--step-length", type=float, default=0.2)
    parser.add_argument("--decision-period", type=float, default=1.0)
    parser.add_argument("--time-to-teleport", type=float, default=None,
                        help="Override SUMO time-to-teleport; use -1 to disable jam teleports.")
    parser.add_argument("--prediction-horizon", type=float, default=30.0)
    parser.add_argument("--prediction-warning-threshold", type=float, default=0.80)
    parser.add_argument("--cooperative-warning-threshold", type=float, default=0.80)
    parser.add_argument("--cooperative-switch-margin", type=float, default=0.12)
    parser.add_argument("--inject-warning-at-s", type=float, default=None,
                        help="Diagnostic only: inject one labeled forecast warning at this SUMO time.")
    parser.add_argument("--inject-warning-signal", default="457026848")
    parser.add_argument("--seed", type=int, default=4172026)
    parser.add_argument("--signals", nargs="*", default=None)
    args = parser.parse_args()
    if min(args.end_time, args.step_length, args.decision_period, args.prediction_horizon) <= 0:
        parser.error("horizonte, passo, intervalo de decisão e horizonte preditivo devem ser positivos")
    if not math.isclose(args.end_time / args.step_length, round(args.end_time / args.step_length), abs_tol=1e-8):
        parser.error("--end-time deve ser múltiplo exato de --step-length")

    network = args.network.resolve()
    catalog = args.catalog.resolve()
    routes = args.routes.resolve()
    profile_file = args.timing_profile.resolve()
    for path in (network, catalog, routes, profile_file):
        if not path.is_file():
            raise FileNotFoundError(path)
    profile = load_timing_profile(profile_file)
    catalog_payload = json.loads(catalog.read_text(encoding="utf-8"))
    signal_rows = catalog_payload["signals"]
    requested_ids = set(args.signals or [str(row["controller_id"]) for row in signal_rows])
    signal_rows = [row for row in signal_rows if str(row["controller_id"]) in requested_ids]
    signal_ids = [str(row["controller_id"]) for row in signal_rows]
    if not signal_rows or set(signal_ids) != requested_ids:
        raise ValueError(f"Sinais ausentes do catálogo: {sorted(requested_ids - set(signal_ids))}")

    topology = SignalTopology(network, catalog)
    controllers = {str(row["controller_id"]): controller_from_profile(row, profile) for row in signal_rows}
    movements_by_tls = topology.movements_by_tls
    green_links: dict[str, dict[int, set[int]]] = {}
    green_edges: dict[str, dict[int, set[str]]] = {}
    for tls_id, controller in controllers.items():
        green_links[tls_id] = {}
        green_edges[tls_id] = {}
        for green_phase in controller.plan.green_phases:
            phase_state = controller.plan.phases[green_phase].state
            links = {idx for idx, char in enumerate(phase_state) if char in "Gg"}
            edges = {
                movement["receiver_edge_id"]
                for link in links
                for movement in topology.movements_by_link.get((tls_id, link), [])
            }
            green_links[tls_id][green_phase] = links
            green_edges[tls_id][green_phase] = edges

    run_id = f"{args.run_id_prefix}_{args.mode}_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}_{uuid.uuid4().hex[:6]}"
    run_dir = args.output_root.resolve() / run_id
    run_dir.mkdir(parents=True, exist_ok=False)
    paths = {
        "header": run_dir / "execution_header.json",
        "summary": run_dir / "summary.json",
        "observations": run_dir / "observations_by_green.csv",
        "network_metrics": run_dir / "network_metrics.csv",
        "prediction_evaluation": run_dir / "prediction_evaluation.csv",
        "unexpected_blocks": run_dir / "unexpected_block_events.jsonl",
        "actions": run_dir / "actions.jsonl",
        "phase_trace": run_dir / "phase_trace.jsonl",
        "sumo_stdout": run_dir / "sumo_stdout.log",
        "sumo_errors": run_dir / "sumo_errors.log",
        "sumo_messages": run_dir / "sumo_messages.log",
        "tripinfo": run_dir / "tripinfo.xml",
        "collisions": run_dir / "collisions.xml",
        "summary_xml": run_dir / "sumo_summary.xml",
        "vehicle_accounting": run_dir / "vehicle_accounting.json",
    }
    sim_binary = discover_sumo(args.ui == "gui")
    version = subprocess.run([str(sim_binary), "--version"], check=True, capture_output=True, text=True)
    scheduled = scheduled_departures(routes)
    command = [
        str(sim_binary), "--net-file", str(network), "--route-files", str(routes),
        "--begin", "0", "--end", f"{args.end_time:g}", "--step-length", f"{args.step_length:g}",
        "--seed", str(args.seed), "--no-step-log", "--duration-log.statistics",
        "--tripinfo-output", str(paths["tripinfo"]), "--tripinfo-output.write-unfinished",
        "--tripinfo-output.write-undeparted", "--collision-output", str(paths["collisions"]),
        "--collision.check-junctions", "--summary-output", str(paths["summary_xml"]),
        "--summary-output.period", "10", "--error-log", str(paths["sumo_errors"]),
        "--message-log", str(paths["sumo_messages"]),
    ]
    if args.time_to_teleport is not None:
        command += ["--time-to-teleport", f"{args.time_to_teleport:g}"]
    if args.ui == "gui":
        view_settings = C3_RUN / "viewsettings.xml"
        if view_settings.is_file():
            command += ["--gui-settings-file", str(view_settings)]
        if args.gui_delay_ms > 0:
            command += ["--delay", str(args.gui_delay_ms)]
        # Let SUMO-GUI close its own window at the end. Without this flag its
        # end-of-simulation modal can block TraCI and leave tripinfo incomplete.
        command += ["--quit-on-end"]
        command += ["--start"]
    header = {
        "schema_version": 1,
        "run_id": run_id,
        "mode": args.mode,
        "policy_description": {
            "predictive": "Regra diagnóstica: pede amarelo após piso se maior previsão de saída/trecho atingir 0.80; limiar não calibrado.",
            "reactive": "Regra diagnóstica sem previsão: pede amarelo quando capacidade observada chega a 0.95 em duas amostras únicas.",
            "cooperative": "Controlador FluxIA adaptativo experimental: compara fila, espera e risco do trecho receptor; escolhe entre manter/estender o verde e solicitar amarelo, depois seleciona somente verdes admitidos pela máscara C2. Amarelo e clearance permanecem no programa C2.",
            "native": "Programas SUMO C2 sem ação externa; mesma telemetria e mesmos indicadores.",
        }[args.mode],
        "ui": args.ui,
        "network": {"path": str(network), "sha256": sha256(network)},
        "signal_catalog": {"path": str(catalog), "sha256": sha256(catalog)},
        "demand": {"path": str(routes), "sha256": sha256(routes), "scheduled_vehicles": len(scheduled)},
        "timing_profile": {"path": str(profile_file), "sha256": sha256(profile_file)},
        "controlled_signal_ids": signal_ids,
        "simulation": {
            "sumo_version": next((line.strip() for line in version.stdout.splitlines() if line.startswith("Eclipse SUMO")), "unknown"),
            "seed": args.seed,
            "begin_s": 0.0,
            "end_s": args.end_time,
            "step_s": args.step_length,
            "decision_period_s": args.decision_period,
            "prediction_horizon_s": args.prediction_horizon,
            "teleport_rule": ("SUMO default" if args.time_to_teleport is None else f"--time-to-teleport {args.time_to_teleport:g}"),
            "forecast_threshold": args.prediction_warning_threshold,
            "cooperative_score": {
                "formula": "0.45*min(queue_vehicles/10,1) + 0.35*min(wait_seconds/60,1) - 1.25*max(observed_receiver_fraction,predicted_receiver_fraction)",
                "warning_threshold": args.cooperative_warning_threshold,
                "switch_margin": args.cooperative_switch_margin,
                "green_floor_and_cap": "C2 experimental green timing profile",
                "yellow_and_clearance": "unchanged C2 SUMO phases and durations",
            },
            "diagnostic_injection": None if args.inject_warning_at_s is None else {
                "time_s": args.inject_warning_at_s,
                "signal_id": args.inject_warning_signal,
                "meaning": "synthetic forecast used only to prove the selected controller action-to-phase path; excluded from fair policy comparisons",
            },
            "forecast_status": "experimental, uncalibrated; not evidence of real-world predictive effectiveness",
            "command": command,
        },
        "provenance": {
            "vehicle_profiles": "Current SUMO state used only to associate observed vehicles with movements; future route trajectory is not used as a predictor input.",
            "forecast_schedule": "Remaining current phase from TraCI; later nominal phase durations are a forecast assumption and are recomputed after each observed phase change/extension.",
            "receiving_stage_aggregation": "maximum capacity fraction among distinct receiver edges in the green stage; no cross-street average.",
            "repeat_samples": "One ObservationService snapshot per SUMO time; full-sample counters only advance on a distinct snapshot_id.",
        },
        "outputs": {key: str(value) for key, value in paths.items()},
        "started_at_utc": utc_now(),
    }
    write_json(paths["header"], header)

    counters: dict[tuple[str, int], dict[str, Any]] = defaultdict(lambda: {"last_snapshot": None, "consecutive_full": 0})
    waiting_since: dict[tuple[str, int], float] = {}
    green_extended_phase: dict[str, int] = {}
    pending_predictions: list[dict[str, Any]] = []
    prediction_rows: list[dict[str, Any]] = []
    unexpected_block_events: list[dict[str, Any]] = []
    sample_status: dict[str, dict[int, DestinationStatus | None]] = {}
    sample_green_details: dict[str, dict[int, dict[str, Any]]] = {}
    latest_snapshot: dict[str, Any] | None = None
    latest_observations: dict[str, dict[str, Any]] = {}
    service: ObservationService | None = None
    connection = None
    transition_counts: dict[str, int] = defaultdict(int)
    phase_previous: dict[str, tuple[int, str]] = {}
    last_logged_clearance: dict[str, str] = {}
    full_hold_started: dict[str, float] = {}
    full_hold_reason: dict[str, str] = {}
    all_red_durations: list[dict[str, Any]] = []
    departed_total = arrived_total = teleported_start_total = teleported_end_total = 0
    departed_ids: set[str] = set()
    arrived_ids: set[str] = set()
    teleport_started_ids: set[str] = set()
    teleport_ended_ids: set[str] = set()
    active_ids_end: set[str] = set()
    pending_ids_end: set[str] = set()
    last_progress_bucket = -1
    injection_applied = False
    # SUMO processes departures at times strictly before the final boundary.
    # A vehicle with depart == end_time is written as not-yet-departed.
    end_scheduled_count = sum(depart < args.end_time for depart, _ in scheduled)
    label = run_id
    step_count = 0
    sim_error: str | None = None

    with paths["observations"].open("w", newline="", encoding="utf-8-sig") as observations_stream, \
         paths["network_metrics"].open("w", newline="", encoding="utf-8-sig") as metrics_stream, \
         paths["actions"].open("w", encoding="utf-8") as action_stream, \
         paths["phase_trace"].open("w", encoding="utf-8") as phase_stream, \
         paths["sumo_stdout"].open("w", encoding="utf-8", errors="replace") as stdout:
        observation_writer = csv.DictWriter(observations_stream, fieldnames=[
            "time_s", "snapshot_id", "signal_id", "phase_index", "phase_state", "phase_age_s", "phase_remaining_s",
            "phase_age_source", "green_phase", "receiver_edges", "vehicle_count", "capacity_estimate", "observed_fraction_max",
            "predicted_fraction_max", "sample_age_s", "consecutive_full_samples", "source",
        ])
        observation_writer.writeheader()
        metrics_writer = csv.DictWriter(metrics_stream, fieldnames=[
            "time_s", "scheduled_so_far", "departed_cumulative", "arrived_cumulative", "active_vehicles",
            "pending_scheduled", "simulator_min_expected", "observed_queue_vehicles", "observed_vehicles",
            "collisions_this_step", "teleport_starts_cumulative", "teleport_ends_cumulative",
        ])
        metrics_writer.writeheader()
        try:
            traci.start(command, label=label, numRetries=90, stdout=stdout, verbose=False)
            connection = traci.getConnection(label)
            service = ObservationService(topology, connection, horizon_seconds=args.prediction_horizon, active_signal_ids=set(signal_ids))
            next_sample = args.decision_period
            next_decision = args.decision_period
            while float(connection.simulation.getTime()) < args.end_time - 1e-9:
                connection.simulationStep()
                step_count += 1
                now = float(connection.simulation.getTime())
                departed_total += int(connection.simulation.getDepartedNumber())
                arrived_total += int(connection.simulation.getArrivedNumber())
                departed_ids.update(connection.simulation.getDepartedIDList())
                arrived_ids.update(connection.simulation.getArrivedIDList())
                starting_teleports = connection.simulation.getStartingTeleportIDList()
                ending_teleports = connection.simulation.getEndingTeleportIDList()
                teleported_start_total += len(starting_teleports)
                teleported_end_total += len(ending_teleports)
                teleport_started_ids.update(starting_teleports)
                teleport_ended_ids.update(ending_teleports)
                for tls_id, controller in controllers.items():
                    phase_idx = int(connection.trafficlight.getPhase(tls_id))
                    state = str(connection.trafficlight.getRedYellowGreenState(tls_id))
                    prior = phase_previous.get(tls_id)
                    if prior != (phase_idx, state):
                        phase_trace = {
                            "time_s": round(now, 3), "signal_id": tls_id,
                            "from_phase": None if prior is None else prior[0],
                            "phase_index": phase_idx, "phase_state": state,
                            "source": "actual SUMO TraCI phase",
                        }
                        phase_stream.write(json.dumps(phase_trace, ensure_ascii=False) + "\n")
                        phase_previous[tls_id] = (phase_idx, state)
                        if phase_idx not in controller.plan.transitions:
                            green_extended_phase.pop(tls_id, None)
                        transition_counts[tls_id] += 1
                        if phase_idx in controller.plan.green_phases:
                            waiting_since[(tls_id, phase_idx)] = now
                        if prior is not None and set(prior[1].lower()) == {"r"} and any(ch in "Gg" for ch in state) and tls_id in full_hold_started:
                            hold_start = full_hold_started.pop(tls_id)
                            all_red_durations.append({
                                "signal_id": tls_id,
                                "start_s": hold_start,
                                "end_s": now,
                                "duration_s": round(now - hold_start, 3),
                                "reason": full_hold_reason.pop(tls_id, "all-red diagnostic hold"),
                                "released_when": "phase actually changed in SUMO; fresh capacity was preferred, native recovery is logged separately",
                            })

                new_sample = now + 1e-9 >= next_sample
                if new_sample:
                    latest_snapshot = service.sample(now)
                    latest_observations = {
                        tls_id: service.controller_observation(tls_id, latest_snapshot, include_forecasts=True, now_s=now)
                        for tls_id in signal_ids
                    }
                    forecast_lookup = {
                        (movement["movement_id"], option["path_id"]): option.get("forecast")
                        for tls_id in signal_ids
                        for movement_row in latest_observations[tls_id]["movements"]
                        for movement in [movement_row]
                        for option in movement["downstream_options"]
                    }
                    sample_status = {}
                    sample_green_details = {}
                    for tls_id in signal_ids:
                        tls_view = latest_observations[tls_id]["signal_state"] or {}
                        sample_status[tls_id] = {}
                        sample_green_details[tls_id] = {}
                        for green_phase, edge_ids in green_edges[tls_id].items():
                            observed, edge_rows = edge_fraction(latest_snapshot, edge_ids)
                            counts = sum(int(row.get("vehicle_count", 0)) for row in edge_rows)
                            capacities = sum(int(row.get("capacity_estimate_vehicles", 0)) for row in edge_rows)
                            predicted_values = []
                            source_movements = []
                            for link_index in green_links[tls_id][green_phase]:
                                for movement in topology.movements_by_link.get((tls_id, link_index), []):
                                    source_movements.append(movement)
                                    for option in movement["downstream_options"]:
                                        forecast = forecast_lookup.get((movement["movement_id"], option["path_id"])) or {}
                                        value = forecast.get("predicted_storage_fraction_estimate")
                                        if isinstance(value, (float, int)) and math.isfinite(float(value)):
                                            predicted_values.append(float(value))
                                        pending_predictions.append({
                                            "requested_at_s": now,
                                            "due_at_s": now + args.prediction_horizon,
                                            "signal_id": tls_id,
                                            "green_phase": green_phase,
                                            "movement_id": movement["movement_id"],
                                            "path_id": option["path_id"],
                                            "edge_ids": list(option["segment_edge_ids"]),
                                            "forecast_fraction": value,
                                            "persistence_fraction": actual_path_fraction(latest_snapshot, list(option["segment_edge_ids"])),
                                            "forecast_stock_vehicles": forecast.get("predicted_stock_vehicles"),
                                            "persistence_stock_vehicles": forecast.get("current_stock_vehicles"),
                                            "observed_source": "TraCI current snapshot",
                                            "forecast_assumption": forecast["assumptions"],
                                        })
                            predicted = max(predicted_values) if predicted_values else None
                            if (
                                args.mode in {"predictive", "cooperative"}
                                and not injection_applied
                                and args.inject_warning_at_s is not None
                                and tls_id == args.inject_warning_signal
                                and green_phase == int(connection.trafficlight.getPhase(tls_id))
                                and now + 1e-9 >= args.inject_warning_at_s
                            ):
                                predicted = max(float(predicted or 0.0), args.prediction_warning_threshold + 0.05)
                                injection_applied = True
                            state_info = {
                                "edge_ids": sorted(edge_ids), "edge_rows": edge_rows,
                                "vehicle_count": counts, "capacity": capacities,
                                "observed_fraction": observed, "predicted_fraction": predicted,
                                "phase_age_s": tls_view.get("phase_age_s"),
                                "phase_remaining_s": tls_view.get("phase_remaining_s"),
                            }
                            sample_green_details[tls_id][green_phase] = state_info
                            history = counters[(tls_id, green_phase)]
                            if history["last_snapshot"] != latest_snapshot["snapshot_id"]:
                                if observed is not None and observed >= controller.blocked_threshold:
                                    history["consecutive_full"] += 1
                                else:
                                    history["consecutive_full"] = 0
                                history["last_snapshot"] = latest_snapshot["snapshot_id"]
                            sample_status[tls_id][green_phase] = None if observed is None else DestinationStatus(
                                observed_capacity_fraction=float(observed),
                                measurement_age_s=0.0,
                                consecutive_observed_full_samples=int(history["consecutive_full"]),
                                predicted_capacity_fraction=predicted,
                            )
                            observation_writer.writerow({
                                "time_s": round(now, 3), "snapshot_id": latest_snapshot["snapshot_id"],
                                "signal_id": tls_id, "phase_index": tls_view.get("phase_index"),
                                "phase_state": tls_view.get("phase_state"), "phase_age_s": tls_view.get("phase_age_s"),
                                "phase_remaining_s": tls_view.get("phase_remaining_s"),
                                "phase_age_source": tls_view.get("phase_age_source"), "green_phase": green_phase,
                                "receiver_edges": json.dumps(edge_rows, ensure_ascii=False),
                                "vehicle_count": counts, "capacity_estimate": capacities,
                                "observed_fraction_max": observed, "predicted_fraction_max": predicted,
                                "sample_age_s": 0.0, "consecutive_full_samples": history["consecutive_full"],
                                "source": "TraCI actual state; max by receiver edge; forecast uncalibrated",
                            })
                            if observed is not None and observed >= controller.blocked_threshold and (
                                predicted is None or predicted < args.prediction_warning_threshold
                            ):
                                unexpected_block_events.append({
                                    "time_s": round(now, 3), "snapshot_id": latest_snapshot["snapshot_id"],
                                    "signal_id": tls_id, "green_phase": green_phase,
                                    "observed_fraction_max": observed,
                                    "predicted_fraction_max": predicted,
                                    "definition": "observed receiver max reached blocking threshold but forecast was below warning threshold or unavailable",
                                    "receiver_edges": edge_rows,
                                })

                    still_pending = []
                    for record in pending_predictions:
                        if now + 1e-9 < record["due_at_s"]:
                            still_pending.append(record)
                            continue
                        actual = actual_path_fraction(latest_snapshot, record["edge_ids"])
                        actual_stock = actual_path_stock(latest_snapshot, record["edge_ids"])
                        prediction_rows.append({
                            "requested_at_s": record["requested_at_s"], "evaluated_at_s": now,
                            "signal_id": record["signal_id"], "green_phase": record["green_phase"],
                            "movement_id": record["movement_id"], "path_id": record["path_id"],
                            "forecast_fraction": record["forecast_fraction"],
                            "persistence_fraction": record["persistence_fraction"],
                            "actual_fraction_at_horizon": actual,
                            "forecast_stock_vehicles": record["forecast_stock_vehicles"],
                            "persistence_stock_vehicles": record["persistence_stock_vehicles"],
                            "actual_stock_vehicles_at_horizon": actual_stock,
                            "forecast_error_abs": None if actual is None or record["forecast_fraction"] is None else abs(float(record["forecast_fraction"]) - actual),
                            "persistence_error_abs": None if actual is None or record["persistence_fraction"] is None else abs(float(record["persistence_fraction"]) - actual),
                            "forecast_error_abs_vehicles": None if actual_stock is None or record["forecast_stock_vehicles"] is None else abs(float(record["forecast_stock_vehicles"]) - actual_stock),
                            "persistence_error_abs_vehicles": None if actual_stock is None or record["persistence_stock_vehicles"] is None else abs(float(record["persistence_stock_vehicles"]) - actual_stock),
                            "warning_threshold": args.prediction_warning_threshold,
                            "false_alarm": bool(actual is not None and record["forecast_fraction"] is not None and float(record["forecast_fraction"]) >= args.prediction_warning_threshold and actual < args.prediction_warning_threshold),
                            "missed_high": bool(actual is not None and record["forecast_fraction"] is not None and float(record["forecast_fraction"]) < args.prediction_warning_threshold and actual >= args.prediction_warning_threshold),
                        })
                    pending_predictions = still_pending
                    while next_sample <= now + 1e-9:
                        next_sample += args.decision_period

                # The phase machine is inspected every SUMO step. Policy choices
                # are spaced out; yellow and all-red transitions are not.
                for tls_id, controller in controllers.items():
                    phase_idx = int(connection.trafficlight.getPhase(tls_id))
                    phase_age = float(connection.trafficlight.getSpentDuration(tls_id))
                    phase_state = str(connection.trafficlight.getRedYellowGreenState(tls_id))
                    data_age = float("inf") if latest_snapshot is None else max(0.0, now - float(latest_snapshot["time_s"]))
                    data_fresh = latest_snapshot is not None and data_age <= controller.max_measurement_age_s
                    statuses = sample_status.get(tls_id, {})
                    decisions_due = now + 1e-9 >= next_decision
                    is_green = phase_idx in controller.plan.transitions
                    request: SignalAction | None = None
                    reason = "transition_monitor"
                    cooperative_decision: dict[str, Any] | None = None
                    if args.mode == "native":
                        pass
                    elif is_green and decisions_due:
                        status = statuses.get(phase_idx)
                        observed = None if status is None else status.observed_capacity_fraction
                        predicted = None if status is None else status.predicted_capacity_fraction
                        threshold = args.prediction_warning_threshold if args.mode == "predictive" else controller.blocked_threshold
                        signal = next(row for row in signal_rows if str(row["controller_id"]) == tls_id)
                        nominal = controller.plan.phases[phase_idx].duration_s
                        transition = controller.plan.transitions[phase_idx]
                        if args.mode == "cooperative":
                            allowed_green = controller.allowed_actions(
                                phase_index=phase_idx,
                                phase_elapsed_s=phase_age,
                                data_fresh=data_fresh,
                                downstream_blocked_by_green=statuses,
                                simulation_step_s=args.step_length,
                            )

                            def make_candidate(green_phase: int) -> GreenCandidate:
                                green_status = statuses.get(green_phase)
                                return GreenCandidate(
                                    phase_index=green_phase,
                                    local_queue_vehicles=approach_queue_for_green(
                                        latest_snapshot, topology, tls_id, green_links[tls_id], green_phase,
                                    ),
                                    waiting_seconds=max(
                                        0.0,
                                        now - waiting_since.setdefault((tls_id, green_phase), 0.0),
                                    ),
                                    observed_receiver_fraction=(
                                        None if green_status is None else green_status.observed_capacity_fraction
                                    ),
                                    predicted_receiver_fraction=(
                                        None if green_status is None else green_status.predicted_capacity_fraction
                                    ),
                                )

                            current_candidate = make_candidate(phase_idx)
                            alternative_candidates = []
                            for green_phase in controller.plan.green_phases:
                                if green_phase == phase_idx:
                                    continue
                                green_status = statuses.get(green_phase)
                                if green_status is None:
                                    continue
                                confirmed_full = (
                                    green_status.observed_capacity_fraction >= controller.blocked_threshold
                                    and green_status.consecutive_observed_full_samples >= controller.blocked_confirmation_samples
                                )
                                if not confirmed_full:
                                    alternative_candidates.append(make_candidate(green_phase))
                            should_switch, switch_reason, cooperative_decision = should_request_yellow(
                                current_candidate,
                                alternative_candidates,
                                warning_threshold=args.cooperative_warning_threshold,
                                switch_margin=args.cooperative_switch_margin,
                            )
                            yellow_is_allowed = any(action.kind == "request_yellow" for action in allowed_green)
                            if should_switch and yellow_is_allowed:
                                request = SignalAction("request_yellow")
                                reason = switch_reason
                                if (
                                    injection_applied
                                    and args.inject_warning_signal == tls_id
                                    and math.isclose(now, args.inject_warning_at_s or -1.0, abs_tol=args.step_length)
                                ):
                                    reason = "diagnostic_injected_receiver_risk"
                                    cooperative_decision["diagnostic_injection_used"] = True
                            elif should_switch and not yellow_is_allowed:
                                reason = "green_floor_blocks_early_switch"
                                cooperative_decision["reason"] = reason
                                cooperative_decision["requested_but_masked"] = "request_yellow"
                            elif (
                                phase_age + args.step_length >= nominal - 1e-6
                                and transition.green_max_s is not None
                                and phase_age + args.step_length < transition.green_max_s - 1e-6
                                and green_extended_phase.get(tls_id) != phase_idx
                                and any(action.kind == "extend_green_to_max" for action in allowed_green)
                            ):
                                request = next(action for action in allowed_green if action.kind == "extend_green_to_max")
                                reason = "cooperative_policy_keeps_green_at_native_deadline"
                                cooperative_decision["reason"] = reason
                            else:
                                reason = "cooperative_policy_keeps_current_green"
                                cooperative_decision["reason"] = reason
                        else:
                            # Legacy diagnostic modes retain their experimental rules.
                            should_switch = (
                                observed is not None and observed >= controller.blocked_threshold
                                and status.consecutive_observed_full_samples >= controller.blocked_confirmation_samples
                            )
                            if args.mode == "predictive" and predicted is not None and predicted >= threshold:
                                should_switch = True
                                reason = (
                                    "diagnostic_injected_forecast_threshold"
                                    if injection_applied and args.inject_warning_signal == tls_id and now <= (args.inject_warning_at_s or -1) + args.decision_period
                                    else "experimental_downstream_forecast_threshold"
                                )
                            elif should_switch:
                                reason = "fresh_observed_receiver_full_confirmed"
                            if phase_age + 1e-6 >= transition.green_floor_s and should_switch:
                                request = SignalAction("request_yellow")
                            elif transition.green_max_s is not None and phase_age + args.step_length >= transition.green_max_s:
                                request = SignalAction("request_yellow")
                                reason = "experimental_green_cap_reached"
                            elif phase_age + args.step_length >= nominal:
                                # At the imported nominal end, let SUMO's native
                                # yellow begin unless an explicit extension rule
                                # below is supported by observed queue and space.
                                inbound_queue = 0
                                for link in green_links[tls_id][phase_idx]:
                                    for movement in topology.movements_by_link.get((tls_id, link), []):
                                        lane = latest_snapshot["lane_states"].get(movement["from_lane_id"], {}) if latest_snapshot else {}
                                        inbound_queue += int(lane.get("queue_vehicle_count", 0))
                                if phase_age < nominal - 1e-6 and inbound_queue >= 3 and status is not None and (observed or 0) < 0.80:
                                    extension = max(args.step_length, transition.green_max_s - phase_age - args.step_length)
                                    request = SignalAction("extend_green_to_max", duration_s=round(extension, 6))
                                    reason = "measured_queue_extension_to_experimental_cap"
                        if request is None:
                            request = SignalAction("maintain_green")
                            reason = "maintain_until_next_observation"
                    elif not is_green:
                        allowed = controller.allowed_actions(
                            phase_index=phase_idx,
                            phase_elapsed_s=phase_age,
                            data_fresh=data_fresh,
                            downstream_blocked_by_green=statuses,
                            simulation_step_s=args.step_length,
                        )
                        if any(action.kind == "release_green" for action in allowed):
                            waiting = {green: waiting_since.get((tls_id, green), now) for green in controller.plan.green_phases}
                            if args.mode == "cooperative":
                                eligible = [
                                    GreenCandidate(
                                        phase_index=int(action.target_green_phase),
                                        local_queue_vehicles=approach_queue_for_green(
                                            latest_snapshot, topology, tls_id, green_links[tls_id],
                                            int(action.target_green_phase),
                                        ),
                                        waiting_seconds=max(0.0, now - waiting.get(int(action.target_green_phase), now)),
                                        observed_receiver_fraction=(
                                            statuses[int(action.target_green_phase)].observed_capacity_fraction
                                        ),
                                        predicted_receiver_fraction=(
                                            statuses[int(action.target_green_phase)].predicted_capacity_fraction
                                        ),
                                    )
                                    for action in allowed
                                    if action.target_green_phase is not None
                                    and isinstance(statuses.get(int(action.target_green_phase)), DestinationStatus)
                                ]
                                selected, cooperative_decision = choose_green_candidate(eligible)
                                chosen = next(action for action in allowed if action.target_green_phase == selected.phase_index)
                            else:
                                chosen = controller.choose_fair_release(allowed, waiting, statuses)
                            request = chosen
                            reason = "cooperative_score_after_clearance" if args.mode == "cooperative" else "fresh_receiver_capacity_after_clearance"
                        elif any(action.kind == "hold_all_red" for action in allowed):
                            request = next(action for action in allowed if action.kind == "hold_all_red")
                            reason = "all_receivers_full_confirmed_no_timeout"
                        elif any(action.kind == "hold_for_confirmation" for action in allowed):
                            request = next(action for action in allowed if action.kind == "hold_for_confirmation")
                            reason = "waiting_for_unique_confirmation_sample"
                        elif any(action.kind == "prepare_clearance_boundary" for action in allowed):
                            request = next(action for action in allowed if action.kind == "prepare_clearance_boundary")
                            reason = "inspect_receivers_at_clearance_boundary"
                        elif any(action.kind == "follow_native" for action in allowed):
                            request = SignalAction("follow_native")
                            reason = "stale_or_incomplete_data_native_recovery"
                        elif decisions_due and any(action.kind == "continue_transition" for action in allowed):
                            request = allowed[0]
                            reason = "continue_protected_transition"

                    # Read the mask on every step during protected transitions,
                    # then apply only at an observation/decision boundary.
                    if args.mode != "native" and request is not None:
                        allowed = controller.allowed_actions(
                            phase_index=phase_idx,
                            phase_elapsed_s=phase_age,
                            data_fresh=data_fresh,
                            downstream_blocked_by_green=statuses,
                            simulation_step_s=args.step_length,
                        )
                        executed = request
                        substituted = False
                        if executed not in allowed:
                            substituted = True
                            executed = next((a for a in allowed if a.kind == "follow_native"), allowed[0])
                        if executed.kind in {"request_yellow", "release_green", "hold_all_red", "hold_for_confirmation", "prepare_clearance_boundary", "extend_green_to_max", "follow_native", "maintain_green"}:
                            controller.apply_action(
                                tls_id=tls_id, traci_trafficlight=connection.trafficlight,
                                action=executed, phase_index=phase_idx, phase_elapsed_s=phase_age,
                                data_fresh=data_fresh, downstream_blocked_by_green=statuses,
                                simulation_step_s=args.step_length, now_s=now,
                            )
                        if executed.kind == "extend_green_to_max":
                            green_extended_phase[tls_id] = phase_idx
                        event = {
                            "time_s": round(now, 3), "snapshot_id": None if latest_snapshot is None else latest_snapshot["snapshot_id"],
                            "signal_id": tls_id, "mode": args.mode, "phase_before": phase_idx,
                            "phase_state_before": phase_state, "phase_age_s": round(phase_age, 3),
                            "observation_age_s": None if not math.isfinite(data_age) else round(data_age, 3),
                            "requested": request.key, "allowed": [item.key for item in allowed],
                            "executed": executed.key, "substituted": substituted, "reason": reason,
                            "cooperative_decision": cooperative_decision,
                            "receiver_status_by_green": {
                                str(g): None if s is None else {
                                    "observed_fraction_max": s.observed_capacity_fraction,
                                    "predicted_fraction_max": s.predicted_capacity_fraction,
                                    "consecutive_full_unique_samples": s.consecutive_observed_full_samples,
                                    "measurement_age_s": s.measurement_age_s,
                                } for g, s in statuses.items()
                            },
                        }
                        action_stream.write(json.dumps(event, ensure_ascii=False) + "\n")
                        if executed.kind == "request_yellow":
                            waiting_since[(tls_id, phase_idx)] = now
                        if executed.kind in {"hold_all_red", "hold_for_confirmation"}:
                            full_hold_started.setdefault(tls_id, now)
                            full_hold_reason.setdefault(tls_id, reason)
                            last_logged_clearance[tls_id] = executed.kind
                    if is_green and not decisions_due:
                        # Checking the mask/phase keeps the transition controller
                        # synchronized even between policy decision ticks.
                        controller.allowed_actions(
                            phase_index=phase_idx, phase_elapsed_s=phase_age,
                            data_fresh=data_fresh, downstream_blocked_by_green=statuses,
                            simulation_step_s=args.step_length,
                        )

                if decisions_due:
                    while next_decision <= now + 1e-9:
                        next_decision += args.decision_period

                if abs(now - round(now)) < args.step_length / 2:
                    scheduled_so_far = sum(depart < now for depart, _ in scheduled)
                    active_ids = connection.vehicle.getIDList()
                    queue_count = 0 if latest_snapshot is None else sum(
                        int(row["queue_vehicle_count"]) for row in latest_snapshot["lane_states"].values()
                    )
                    vehicle_count = 0 if latest_snapshot is None else sum(
                        int(row["vehicle_count"]) for row in latest_snapshot["edge_states"].values()
                    )
                    metrics_writer.writerow({
                        "time_s": round(now, 3), "scheduled_so_far": scheduled_so_far,
                        "departed_cumulative": departed_total, "arrived_cumulative": arrived_total,
                        "active_vehicles": len(active_ids),
                        "pending_scheduled": max(0, scheduled_so_far - departed_total),
                        "simulator_min_expected": connection.simulation.getMinExpectedNumber(),
                        "observed_queue_vehicles": queue_count, "observed_vehicles": vehicle_count,
                        "collisions_this_step": connection.simulation.getCollidingVehiclesNumber(),
                        "teleport_starts_cumulative": teleported_start_total,
                        "teleport_ends_cumulative": teleported_end_total,
                    })

                bucket = int(now // 30)
                if bucket > last_progress_bucket:
                    last_progress_bucket = bucket
                    print(f"[{run_id}] SUMO t={now:.1f}/{args.end_time:.1f}s; loaded={departed_total}, arrived={arrived_total}, active={connection.vehicle.getIDCount()}", flush=True)

            active_ids_end = set(connection.vehicle.getIDList())
            pending_ids_end = set(connection.simulation.getPendingVehicles())
            active_end = len(active_ids_end)
            pending_end = len(pending_ids_end)
            colliding_ids = list(connection.simulation.getCollidingVehiclesIDList())
            for stream in (observations_stream, metrics_stream, action_stream, phase_stream, stdout):
                stream.flush()
        except Exception as exc:
            sim_error = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            if connection is not None:
                try:
                    if args.ui == "gui":
                        # Closing SUMO-GUI through the TraCI command can block
                        # behind its end-of-simulation modal. Drop only this
                        # run's socket so output files can be finalized while
                        # the user can inspect the finished map window.
                        sock = getattr(connection, "_socket", None)
                        if sock is not None:
                            sock.close()
                            connection._socket = None
                    else:
                        connection.close()
                except Exception:
                    pass

    with paths["prediction_evaluation"].open("w", newline="", encoding="utf-8-sig") as stream:
        fieldnames = [
            "requested_at_s", "evaluated_at_s", "signal_id", "green_phase", "movement_id", "path_id",
            "forecast_fraction", "persistence_fraction", "actual_fraction_at_horizon",
            "forecast_stock_vehicles", "persistence_stock_vehicles", "actual_stock_vehicles_at_horizon",
            "forecast_error_abs", "persistence_error_abs", "forecast_error_abs_vehicles", "persistence_error_abs_vehicles",
            "warning_threshold", "false_alarm", "missed_high",
        ]
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(prediction_rows)
    with paths["unexpected_blocks"].open("w", encoding="utf-8") as stream:
        for row in unexpected_block_events:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")

    errors = [float(row["forecast_error_abs"]) for row in prediction_rows if row["forecast_error_abs"] is not None]
    persistence_errors = [float(row["persistence_error_abs"]) for row in prediction_rows if row["persistence_error_abs"] is not None]
    vehicle_errors = [float(row["forecast_error_abs_vehicles"]) for row in prediction_rows if row["forecast_error_abs_vehicles"] is not None]
    persistence_vehicle_errors = [float(row["persistence_error_abs_vehicles"]) for row in prediction_rows if row["persistence_error_abs_vehicles"] is not None]
    trip_root, tripinfo_xml_error = parse_xml_if_complete(paths["tripinfo"])
    trip_rows = [] if trip_root is None else trip_root.findall("tripinfo")
    completed_trip_rows = [row for row in trip_rows if row.get("arrival") not in {None, "-1", "-1.00"}]
    tripinfo_completed_ids = {row.get("id", "") for row in completed_trip_rows if row.get("id")}
    tripinfo_started_unfinished_ids = {
        row.get("id", "") for row in trip_rows
        if row.get("id") and row.get("depart") not in {None, "-1", "-1.00"}
        and row.get("arrival") in {None, "-1", "-1.00"}
    }
    tripinfo_uninserted_ids = {
        row.get("id", "") for row in trip_rows
        if row.get("id") and row.get("depart") in {None, "-1", "-1.00"}
    }
    tripinfo_ids = {row.get("id", "") for row in trip_rows if row.get("id")}
    durations = [float(row.get("duration")) for row in completed_trip_rows if row.get("duration") not in {None, ""}]
    waits = [float(row.get("waitingTime")) for row in completed_trip_rows if row.get("waitingTime") not in {None, ""}]
    collision_root, collision_xml_error = parse_xml_if_complete(paths["collisions"])
    collision_events = [] if collision_root is None else collision_root.findall("collision")
    collision_affected_ids = sorted({
        value
        for row in collision_events
        for value in (row.get("collider"), row.get("victim"))
        if value
    })
    scheduled_by_end_ids = {vehicle_id for depart, vehicle_id in scheduled if depart < args.end_time}
    not_yet_scheduled_ids = {vehicle_id for depart, vehicle_id in scheduled if depart > args.end_time}
    due_not_departed_ids = scheduled_by_end_ids - departed_ids
    teleports_in_progress_ids = teleport_started_ids - teleport_ended_ids
    departed_not_classified_ids = departed_ids - arrived_ids - active_ids_end - teleports_in_progress_ids
    unresolved_due_not_inserted_ids = due_not_departed_ids - pending_ids_end - tripinfo_uninserted_ids
    missing_due_from_tripinfo_ids = scheduled_by_end_ids - tripinfo_ids
    tripinfo_unaccounted_departed_ids = departed_ids - tripinfo_completed_ids - tripinfo_started_unfinished_ids
    accounting = {
        "schema_version": 1,
        "run_id": run_id,
        "as_of_simulation_time_s": args.end_time,
        "scheduled_total_ids": len(scheduled),
        "scheduled_due_by_end_ids": len(scheduled_by_end_ids),
        "scheduled_after_end_ids": len(not_yet_scheduled_ids),
        "departed_inserted_ids": sorted(departed_ids),
        "arrived_completed_ids": sorted(arrived_ids),
        "active_at_end_ids": sorted(active_ids_end),
        "pending_entry_at_end_ids": sorted(pending_ids_end),
        "due_but_not_inserted_ids": sorted(due_not_departed_ids),
        "tripinfo_completed_ids": sorted(tripinfo_completed_ids),
        "tripinfo_started_but_unfinished_ids": sorted(tripinfo_started_unfinished_ids),
        "tripinfo_never_inserted_ids": sorted(tripinfo_uninserted_ids),
        "due_not_inserted_without_pending_or_tripinfo_record_ids": sorted(unresolved_due_not_inserted_ids),
        "scheduled_due_ids_missing_from_tripinfo_ids": sorted(missing_due_from_tripinfo_ids),
        "departed_ids_without_completed_or_unfinished_tripinfo_ids": sorted(tripinfo_unaccounted_departed_ids),
        "teleport_started_affected_ids": sorted(teleport_started_ids),
        "teleport_ended_affected_ids": sorted(teleport_ended_ids),
        "teleport_in_progress_at_end_ids": sorted(teleports_in_progress_ids),
        "collision_affected_ids": collision_affected_ids,
        "departed_without_arrival_active_or_ongoing_teleport_ids": sorted(departed_not_classified_ids),
        "counts": {
            "scheduled_total": len(scheduled),
            "scheduled_due_by_end": len(scheduled_by_end_ids),
            "departed_inserted": len(departed_ids),
            "arrived_completed": len(arrived_ids),
            "active_at_end": len(active_ids_end),
            "pending_entry_at_end": len(pending_ids_end),
            "due_but_not_inserted": len(due_not_departed_ids),
            "tripinfo_completed": len(tripinfo_completed_ids),
            "tripinfo_started_but_unfinished": len(tripinfo_started_unfinished_ids),
            "tripinfo_never_inserted": len(tripinfo_uninserted_ids),
            "due_not_inserted_without_pending_or_tripinfo_record": len(unresolved_due_not_inserted_ids),
            "scheduled_due_ids_missing_from_tripinfo": len(missing_due_from_tripinfo_ids),
            "departed_ids_without_completed_or_unfinished_tripinfo": len(tripinfo_unaccounted_departed_ids),
            "teleport_started_affected": len(teleport_started_ids),
            "teleport_ended_affected": len(teleport_ended_ids),
            "teleport_in_progress_at_end": len(teleports_in_progress_ids),
            "collision_affected": len(collision_affected_ids),
            "departed_without_arrival_active_or_ongoing_teleport": len(departed_not_classified_ids),
        },
        "checks": {
            "departed_id_count_matches_sumo_departed_counter": len(departed_ids) == departed_total,
            "arrived_id_count_matches_sumo_arrived_counter": len(arrived_ids) == arrived_total,
            "due_not_inserted_is_visible_in_pending_or_tripinfo": len(unresolved_due_not_inserted_ids) == 0,
            "tripinfo_accounts_for_all_scheduled_due_ids": len(missing_due_from_tripinfo_ids) == 0,
            "tripinfo_accounts_for_all_departed_ids": len(tripinfo_unaccounted_departed_ids) == 0,
            "all_departed_ids_classified_at_end": len(departed_not_classified_ids) == 0,
        },
        "interpretation": "Vehicles scheduled after this run's end are not yet due. Due but not inserted IDs and departed IDs without a terminal/active/teleport state remain visible; they are not treated as completed.",
    }
    write_json(paths["vehicle_accounting"], accounting)
    xml_errors = {key: value for key, value in {"tripinfo": tripinfo_xml_error, "collisions": collision_xml_error}.items() if value}
    action_events = [json.loads(line) for line in paths["actions"].read_text(encoding="utf-8").splitlines() if line.strip()]
    reason_counts: dict[str, int] = defaultdict(int)
    for event in action_events:
        reason_counts[str(event.get("reason", "unspecified"))] += 1
    summary = {
        "schema_version": 1,
        "run_id": run_id,
        "mode": args.mode,
        "status": "failed" if sim_error else (
            "completed_visualization_with_incomplete_xml_outputs" if xml_errors and args.ui == "gui" else
            "completed_with_incomplete_xml_outputs" if xml_errors else "completed"
        ),
        "started_at_utc": header["started_at_utc"],
        "finished_at_utc": utc_now(),
        "simulation": {
            "steps": step_count, "actual_end_s": round(step_count * args.step_length, 3),
            "scheduled_before_end": end_scheduled_count, "departed": departed_total,
            "arrived": arrived_total, "active_at_end": active_end, "pending_at_end": pending_end,
            "teleport_starts": teleported_start_total, "teleport_ends": teleported_end_total,
            "colliding_vehicle_ids_at_end": colliding_ids,
            "collision_event_count": len(collision_events) if collision_root is not None else None,
            "tripinfo_rows": len(trip_rows) if trip_root is not None else None,
            "completed_tripinfo_rows": len(completed_trip_rows) if trip_root is not None else None,
            "completed_trip_mean_duration_s": round(fmean(durations), 3) if durations else None,
            "completed_trip_mean_waiting_s": round(fmean(waits), 3) if waits else None,
            "vehicle_accounting_checks": accounting["checks"],
        },
        "control": {
            "controlled_signal_count": len(signal_ids), "controlled_signal_ids": signal_ids,
            "phase_transitions_by_signal": dict(transition_counts),
            "requested_yellow_count": sum(event.get("requested") == "request_yellow" for event in action_events),
            "executed_action_count": len(action_events),
            "substituted_action_count": sum(bool(event.get("substituted")) for event in action_events),
            "reason_counts": dict(reason_counts),
            "all_red_durations": all_red_durations,
            "unexpected_block_samples": len(unexpected_block_events),
        },
        "prediction_evaluation": {
            "rows_at_30s_horizon": len(prediction_rows),
            "forecast_mae_capacity_fraction": round(fmean(errors), 6) if errors else None,
            "persistence_baseline_mae_capacity_fraction": round(fmean(persistence_errors), 6) if persistence_errors else None,
            "valid_forecast_rows": sum(row["forecast_fraction"] is not None for row in prediction_rows),
            "unavailable_forecast_rows": sum(row["forecast_fraction"] is None for row in prediction_rows),
            "forecast_mae_vehicles": round(fmean(vehicle_errors), 6) if vehicle_errors else None,
            "persistence_baseline_mae_vehicles": round(fmean(persistence_vehicle_errors), 6) if persistence_vehicle_errors else None,
            "false_alarm_count": sum(bool(row["false_alarm"]) for row in prediction_rows),
            "missed_high_count": sum(bool(row["missed_high"]) for row in prediction_rows),
            "threshold": args.prediction_warning_threshold,
            "status": "experimental diagnostic; not calibrated and not an efficacy claim",
        },
        "observation_integrity": {
            "unique_snapshots": 0 if service is None else service.unique_sample_count,
            "duplicate_sample_requests": 0 if service is None else service.duplicate_sample_request_count,
            "lane_subscriptions": 0 if service is None else service.lane_subscription_count,
            "tls_subscriptions": 0 if service is None else service.tls_subscription_count,
        },
        "simulation_error": sim_error,
        "xml_output_errors": xml_errors,
        "outputs": {key: str(value) for key, value in paths.items()},
    }
    write_json(paths["summary"], summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if sim_error is None else 1


if __name__ == "__main__":
    raise SystemExit(main())

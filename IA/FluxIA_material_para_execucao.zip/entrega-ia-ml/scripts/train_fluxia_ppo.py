"""Train or evaluate a joint FluxIA signal policy with MaskablePPO.

This entry point is intentionally optional-dependency safe: importing or
compiling it does not import PyTorch. The protected SUMO environment remains
the authority for every phase change and transition.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
DEFAULT_OUTPUT = ROOT / "docs" / "execucao-luna" / "outputs" / "stage11"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def _save_model_atomic(model, path: Path) -> Path:
    """Write a checkpoint beside its destination, then swap it into place."""
    target = Path(path)
    if target.suffix.lower() != ".zip":
        target = target.with_suffix(".zip")
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary_base = target.with_name(f"{target.stem}.{os.getpid()}.tmp")
    model.save(temporary_base)
    # SB3 writes the exact requested path when it already has a suffix, and
    # appends .zip only to extensionless paths. Accept both behaviors.
    written_path = temporary_base if temporary_base.is_file() else Path(f"{temporary_base}.zip")
    if not written_path.is_file():
        raise FileNotFoundError(f"SB3 did not create the temporary checkpoint: {written_path}")
    os.replace(written_path, target)
    return target


def _load_stack():
    try:
        import gymnasium
        import numpy
        import torch
        import traci
        import stable_baselines3
        import sb3_contrib
        from sb3_contrib import MaskablePPO
        from sb3_contrib.common.wrappers import ActionMasker
    except Exception as exc:
        raise RuntimeError(
            "Pilha PPO indisponível. Instale requirements-rl.txt no ambiente isolado "
            "e confirme que torch e sb3-contrib importam antes de treinar."
        ) from exc
    return {
        "gymnasium": gymnasium,
        "numpy": numpy,
        "torch": torch,
        "traci": traci,
        "stable_baselines3": stable_baselines3,
        "sb3_contrib": sb3_contrib,
        "MaskablePPO": MaskablePPO,
        "ActionMasker": ActionMasker,
    }


def _make_environment(args, *, wrapped: bool):
    from scripts.fluxia_gym_env import FluxIASumoEnv

    paths = {
        key: getattr(args, key)
        for key in ("network", "catalog", "routes", "timing_profile")
        if getattr(args, key, None) is not None
    }
    training_routes = getattr(args, "training_routes", None)
    if training_routes:
        paths["route_candidates"] = training_routes

    env_kwargs = {
        "end_time_s": args.episode_horizon,
        "seed": args.seed,
        "output_root": args.episode_output,
        "gui": getattr(args, "gui", False),
        "gui_delay_ms": getattr(args, "gui_delay_ms", 0),
        "gui_settings_file": getattr(args, "gui_settings_file", None),
        **paths,
    }
    if not wrapped:
        if int(getattr(args, "n_envs", 1)) != 1:
            raise ValueError("--n-envs só se aplica ao treino; avaliação usa uma simulação por vez")
        return FluxIASumoEnv(**env_kwargs)
    stack = _load_stack()
    n_envs = int(getattr(args, "n_envs", 1))
    if n_envs < 1:
        raise ValueError("--n-envs deve ser pelo menos 1")
    if n_envs == 1:
        env = FluxIASumoEnv(**env_kwargs)
        return stack["ActionMasker"](env, lambda wrapped_env: wrapped_env.action_masks())
    if env_kwargs["gui"]:
        raise ValueError("Treino paralelo requer --gui desativado; cada processo SUMO roda headless")

    # FluxIASumoEnv implements action_masks() itself, as required by
    # MaskablePPO with SubprocVecEnv on Windows.
    from stable_baselines3.common.vec_env import SubprocVecEnv

    def make_worker(worker_index: int):
        worker_kwargs = dict(env_kwargs)
        worker_kwargs["seed"] = int(args.seed) + int(worker_index)

        def initialize():
            return FluxIASumoEnv(**worker_kwargs)

        return initialize

    return SubprocVecEnv(
        [make_worker(index) for index in range(n_envs)],
        start_method="spawn",
    )


def _package_versions(stack: dict[str, Any]) -> dict[str, str]:
    torch = stack["torch"]
    cuda_available = bool(torch.cuda.is_available())
    return {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "torch": torch.__version__,
        "torch_cuda_runtime": str(torch.version.cuda or "none"),
        "cuda_available": str(cuda_available),
        "gpu_name": str(torch.cuda.get_device_name(0)) if cuda_available else "none",
        "gymnasium": stack["gymnasium"].__version__,
        "numpy": stack["numpy"].__version__,
        "stable_baselines3": stack["stable_baselines3"].__version__,
        "sb3_contrib": stack["sb3_contrib"].__version__,
        "traci": stack["traci"].__version__,
    }


def _resolve_device(requested: str, torch_module) -> str:
    if requested == "auto":
        return "cuda" if torch_module.cuda.is_available() else "cpu"
    if requested == "cuda" and not torch_module.cuda.is_available():
        raise RuntimeError("--device cuda foi solicitado, mas torch.cuda.is_available() retornou False")
    return requested


def _policy_digest(model) -> str:
    """Stable digest of the trainable policy parameters for learning evidence."""
    digest = hashlib.sha256()
    for name, tensor in sorted(model.policy.state_dict().items()):
        digest.update(name.encode("utf-8"))
        digest.update(tensor.detach().cpu().contiguous().numpy().tobytes())
    return digest.hexdigest()


def _make_callback(
    output: Path,
    *,
    checkpoint_every: int,
    n_envs: int,
    run_state: dict[str, Any],
    run_state_path: Path,
    start_monotonic: float,
):
    from stable_baselines3.common.callbacks import BaseCallback

    class FluxIAMetricsCallback(BaseCallback):
        def __init__(self):
            super().__init__(verbose=0)
            self.episode = 0
            self.rewards: list[dict[str, float]] = [{} for _ in range(n_envs)]
            self.metrics: list[dict[str, float]] = [{} for _ in range(n_envs)]
            self.rows_path = output / "training_episodes.jsonl"
            self.next_checkpoint = checkpoint_every

        def _on_step(self) -> bool:
            infos = self.locals.get("infos", [])
            dones = self.locals.get("dones", [])
            rewards = self.locals.get("rewards", [])
            if len(rewards):
                self.logger.record("fluxia/step_reward", float(sum(rewards) / len(rewards)))
            for env_index, info in enumerate(infos):
                env_rewards = self.rewards[env_index]
                env_metrics = self.metrics[env_index]
                for name, value in info.get("reward_components", {}).items():
                    env_rewards[name] = env_rewards.get(name, 0.0) + float(value)
                env_metrics["arrivals"] = env_metrics.get("arrivals", 0.0) + float(info.get("arrivals_this_interval", 0))
                env_metrics["collisions_vehicle_steps"] = env_metrics.get("collisions_vehicle_steps", 0.0) + float(info.get("collisions_vehicle_steps", 0))
                env_metrics["teleported_vehicles"] = env_metrics.get("teleported_vehicles", 0.0) + len(info.get("teleported_vehicle_ids", []))
                executed_actions = info.get("requested_vs_executed", [])
                env_metrics["actions_requested"] = env_metrics.get("actions_requested", 0.0) + len(executed_actions)
                env_metrics["action_substitutions"] = env_metrics.get("action_substitutions", 0.0) + sum(
                    bool(row.get("substituted")) for row in executed_actions
                )
                env_metrics["max_active_vehicles"] = max(env_metrics.get("max_active_vehicles", 0.0), float(info.get("active_vehicles", 0)))
                env_metrics["max_due_pending"] = max(env_metrics.get("max_due_pending", 0.0), float(info.get("due_pending_vehicles", 0)))
                done = bool(dones[env_index]) if len(dones) > env_index else False
                if done or info.get("terminated_naturally") or info.get("truncated_by_horizon"):
                    self.episode += 1
                    row = {
                        "episode": self.episode,
                        "environment_index": env_index,
                        "timesteps": int(self.num_timesteps),
                        "reward_components": dict(env_rewards),
                        "total_reward": float(sum(env_rewards.values())),
                        "traffic": dict(env_metrics),
                        "end": "terminated" if info.get("terminated_naturally") else "truncated",
                        "run_dir": info.get("run_dir"),
                        "route_file": info.get("route_file"),
                    }
                    with self.rows_path.open("a", encoding="utf-8") as stream:
                        stream.write(json.dumps(row, ensure_ascii=False) + "\n")
                    for name, value in env_rewards.items():
                        self.logger.record_mean(f"fluxia/episode_{name}", value)
                    self.logger.record_mean("fluxia/episode_arrivals", env_metrics.get("arrivals", 0.0))
                    self.logger.record_mean("fluxia/episode_due_pending_max", env_metrics.get("max_due_pending", 0.0))
                    self.rewards[env_index] = {}
                    self.metrics[env_index] = {}
            while checkpoint_every > 0 and self.num_timesteps >= self.next_checkpoint:
                checkpoint_dir = output / "checkpoints"
                checkpoint_dir.mkdir(parents=True, exist_ok=True)
                checkpoint_path = _save_model_atomic(
                    self.model, checkpoint_dir / f"fluxia_{self.next_checkpoint}"
                )
                run_state.update({
                    "status": "running",
                    "updated_at": _utc_now(),
                    "timesteps": int(self.num_timesteps),
                    "last_checkpoint": str(checkpoint_path),
                    "last_checkpoint_timesteps": int(self.num_timesteps),
                    "elapsed_wall_seconds": round(time.monotonic() - start_monotonic, 3),
                })
                _write_json(run_state_path, run_state)
                self.next_checkpoint += checkpoint_every
            return True

    return FluxIAMetricsCallback()


def train(args) -> int:
    stack = _load_stack()
    device = _resolve_device(args.device, stack["torch"])
    if device == "cuda":
        # SUMO workers own the CPU cores; the small PPO policy does not need
        # a large CPU thread pool while its tensors are on the GPU.
        stack["torch"].set_num_threads(1)
    from stable_baselines3.common.logger import configure

    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    env = _make_environment(args, wrapped=True)
    if hasattr(env, "get_attr"):
        signal_ids = env.get_attr("signal_ids")[0]
        action_count_per_signal = env.get_attr("action_count")[0]
    else:
        signal_ids = env.unwrapped.signal_ids
        action_count_per_signal = env.unwrapped.action_count
    signal_count = len(signal_ids)
    model_cls = stack["MaskablePPO"]
    if args.total_timesteps <= 0:
        env.close()
        raise ValueError("--total-timesteps deve ser maior que zero")
    if args.checkpoint_every < 0:
        env.close()
        raise ValueError("--checkpoint-every não pode ser negativo")

    if args.resume:
        model = model_cls.load(args.resume, env=env, device=device)
        # SB3 restores policy/optimizer data from the file, but SUMO and RNG
        # trajectories restart; this is a warm start, not exact continuation.
        # Apply requested PPO settings so command-line values are not silently
        # ignored after loading a checkpoint.
        from stable_baselines3.common.utils import FloatSchedule
        model.learning_rate = float(args.learning_rate)
        model.lr_schedule = FloatSchedule(model.learning_rate)
        model.n_steps = int(args.rollout_steps)
        model.batch_size = int(args.batch_size)
        model.n_epochs = int(args.epochs)
        model.gamma = float(args.gamma)
        model.gae_lambda = float(args.gae_lambda)
        model.clip_range = FloatSchedule(float(args.clip_range))
        model.ent_coef = float(args.entropy)
        # Changing the worker count or rollout length changes the buffer
        # dimensions. SB3 does not resize an already-created buffer when its
        # matching hyperparameters are changed on a loaded model.
        model.rollout_buffer = model.rollout_buffer_class(
            model.n_steps,
            model.observation_space,
            model.action_space,
            device=model.device,
            gamma=model.gamma,
            gae_lambda=model.gae_lambda,
            n_envs=model.n_envs,
            **model.rollout_buffer_kwargs,
        )
        # The SUMO trajectories restart on warm start. Drop episode summaries
        # from the source run so SB3's rolling episode metrics describe only
        # this run, rather than mixing different horizons and route sets.
        if model.ep_info_buffer is not None:
            model.ep_info_buffer.clear()
        if model.ep_success_buffer is not None:
            model.ep_success_buffer.clear()
    else:
        model = model_cls(
            "MlpPolicy", env,
            learning_rate=args.learning_rate,
            n_steps=args.rollout_steps,
            batch_size=args.batch_size,
            n_epochs=args.epochs,
            gamma=args.gamma,
            gae_lambda=args.gae_lambda,
            clip_range=args.clip_range,
            ent_coef=args.entropy,
            policy_kwargs={"net_arch": [128, 128]},
            seed=args.seed,
            device=device,
            verbose=0,
        )
    model.set_logger(configure(str(output / "sb3_logs"), ["csv"]))
    initial_digest = _policy_digest(model)
    initial_checkpoint = output / "initial_checkpoint"
    initial_checkpoint_path = _save_model_atomic(model, initial_checkpoint)

    if hasattr(env, "get_attr"):
        get_env_attr = lambda name: env.get_attr(name)[0]
    else:
        get_env_attr = lambda name: getattr(env.unwrapped, name)
    input_files = {
        "network": Path(get_env_attr("network")),
        "catalog": Path(get_env_attr("catalog")),
        "timing_profile": Path(get_env_attr("timing_profile_path")),
        "training_routes": [Path(path) for path in get_env_attr("route_candidates")],
    }
    environment_config = {
        "network": str(input_files["network"]),
        "catalog": str(input_files["catalog"]),
        "timing_profile": str(input_files["timing_profile"]),
        "route_candidates": [str(path) for path in input_files["training_routes"]],
        "end_time_s": float(get_env_attr("end_time_s")),
        "sumo_step_s": float(get_env_attr("sumo_step_s")),
        "decision_period_s": float(get_env_attr("decision_period_s")),
        "prediction_horizon_s": float(get_env_attr("prediction_horizon_s")),
        "teleport_s": float(get_env_attr("teleport_s")),
    }
    input_hashes = {
        key: hashlib.sha256(path.read_bytes()).hexdigest()
        for key, path in input_files.items()
        if key != "training_routes"
    }
    input_hashes["training_routes"] = [
        hashlib.sha256(path.read_bytes()).hexdigest() for path in input_files["training_routes"]
    ]
    started_at = _utc_now()
    start = time.perf_counter()
    start_monotonic = time.monotonic()
    run_state_path = output / "training_state.json"
    run_state: dict[str, Any] = {
        "status": "running",
        "started_at": started_at,
        "updated_at": started_at,
        "requested_timesteps": int(args.total_timesteps),
        "start_timesteps": int(model.num_timesteps),
        "timesteps": int(model.num_timesteps),
        "last_checkpoint": str(initial_checkpoint_path),
        "last_checkpoint_timesteps": int(model.num_timesteps),
        "output_directory": str(output),
    }
    _write_json(run_state_path, run_state)
    callback = _make_callback(
        output,
        checkpoint_every=args.checkpoint_every,
        n_envs=int(args.n_envs),
        run_state=run_state,
        run_state_path=run_state_path,
        start_monotonic=start_monotonic,
    )
    if args.checkpoint_every > 0:
        callback.next_checkpoint = (int(model.num_timesteps) // args.checkpoint_every + 1) * args.checkpoint_every
    metadata = {
        "created_at": started_at,
        "mode": "train",
        "algorithm": "sb3_contrib.MaskablePPO",
        "policy": f"one joint MultiDiscrete policy over {signal_count} simultaneous signal actions",
        "signal_count": signal_count,
        "action_count_per_signal": action_count_per_signal,
        "n_envs": int(args.n_envs),
        "observation_shape": list(env.observation_space.shape),
        "environment": environment_config,
        "input_sha256": input_hashes,
        "training_route_files": [str(path) for path in input_files["training_routes"]],
        "training_route_sha256": input_hashes["training_routes"],
        "seed": args.seed,
        "requested_device": args.device,
        "resolved_device": device,
        "torch_intraop_threads": int(stack["torch"].get_num_threads()),
        "requested_timesteps": args.total_timesteps,
        "episode_horizon_s": args.episode_horizon,
        "checkpoint_every_timesteps": args.checkpoint_every,
        "hyperparameters": {
            "learning_rate": args.learning_rate, "rollout_steps": args.rollout_steps,
            "batch_size": args.batch_size, "epochs": args.epochs, "gamma": args.gamma,
            "gae_lambda": args.gae_lambda, "clip_range": args.clip_range,
            "entropy": args.entropy,
        },
        "resume_overrides": {
            "learning_rate": args.learning_rate,
            "rollout_steps": args.rollout_steps,
            "batch_size": args.batch_size,
            "epochs": args.epochs,
            "gamma": args.gamma,
            "gae_lambda": args.gae_lambda,
            "clip_range": args.clip_range,
            "entropy": args.entropy,
        } if args.resume else {},
        "versions": _package_versions(stack),
        "initial_policy_sha256": initial_digest,
        "initial_checkpoint": str(initial_checkpoint_path),
        "resume_checkpoint": str(Path(args.resume).resolve()) if args.resume else None,
        "reset_loaded_episode_metrics": bool(args.resume),
        "resume_semantics": "exact rollout/RNG continuation is not implemented; --resume warm-starts from saved policy and optimizer data with a fresh SUMO trajectory",
    }
    _write_json(output / "training_manifest.json", metadata)
    try:
        model.learn(
            total_timesteps=args.total_timesteps,
            callback=callback,
            reset_num_timesteps=not bool(args.resume),
            progress_bar=False,
        )
    except KeyboardInterrupt:
        checkpoint_path = _save_model_atomic(model, output / "interrupted_checkpoint")
        run_state.update({
            "status": "interrupted",
            "updated_at": _utc_now(),
            "timesteps": int(model.num_timesteps),
            "last_checkpoint": str(checkpoint_path),
            "last_checkpoint_timesteps": int(model.num_timesteps),
            "elapsed_wall_seconds": round(time.monotonic() - start_monotonic, 3),
            "message": "Interrupção recebida; checkpoint salvo para warm start.",
        })
        _write_json(run_state_path, run_state)
        _write_json(output / "interrupted.json", run_state)
        return 130
    except Exception as exc:
        checkpoint_path = None
        save_error = None
        try:
            checkpoint_path = _save_model_atomic(model, output / "failed_checkpoint")
        except Exception as checkpoint_exc:  # preserve the original training exception
            save_error = f"{type(checkpoint_exc).__name__}: {checkpoint_exc}"
        run_state.update({
            "status": "failed",
            "updated_at": _utc_now(),
            "timesteps": int(model.num_timesteps),
            "last_checkpoint": str(checkpoint_path) if checkpoint_path else run_state.get("last_checkpoint"),
            "last_checkpoint_timesteps": int(model.num_timesteps) if checkpoint_path else run_state.get("last_checkpoint_timesteps"),
            "elapsed_wall_seconds": round(time.monotonic() - start_monotonic, 3),
            "error": f"{type(exc).__name__}: {exc}",
            "checkpoint_save_error": save_error,
        })
        _write_json(run_state_path, run_state)
        raise
    finally:
        env.close()
    try:
        final_checkpoint_path = _save_model_atomic(model, output / "final_checkpoint")
        final_digest = _policy_digest(model)
        completion = {
            "created_at": _utc_now(), "timesteps": int(model.num_timesteps),
            "wall_seconds": round(time.perf_counter() - start, 3),
            "checkpoint": str(final_checkpoint_path),
            "episodes_logged": callback.episode,
            "resolved_device": device,
            "initial_policy_sha256": initial_digest,
            "final_policy_sha256": final_digest,
            "policy_parameters_changed": initial_digest != final_digest,
            "sb3_progress_csv": str(output / "sb3_logs" / "progress.csv"),
        }
    except Exception as exc:
        run_state.update({
            "status": "failed",
            "updated_at": _utc_now(),
            "timesteps": int(model.num_timesteps),
            "elapsed_wall_seconds": round(time.monotonic() - start_monotonic, 3),
            "error": f"{type(exc).__name__}: {exc}",
        })
        _write_json(run_state_path, run_state)
        raise
    _write_json(output / "training_complete.json", completion)
    run_state.update({
        "status": "completed",
        "updated_at": completion["created_at"],
        "timesteps": int(model.num_timesteps),
        "last_checkpoint": str(final_checkpoint_path),
        "last_checkpoint_timesteps": int(model.num_timesteps),
        "elapsed_wall_seconds": completion["wall_seconds"],
    })
    _write_json(run_state_path, run_state)
    return 0


def evaluate(args) -> int:
    if not args.checkpoint:
        raise ValueError("--checkpoint is required for evaluate mode")
    stack = _load_stack()
    device = _resolve_device(args.device, stack["torch"])
    model = stack["MaskablePPO"].load(args.checkpoint, device=device)
    env = _make_environment(args, wrapped=False)
    obs, reset_info = env.reset(seed=args.seed)
    total_reward = 0.0
    component_totals: dict[str, float] = {}
    done = False
    try:
        while not done:
            action, _ = model.predict(obs, deterministic=True, action_masks=env.action_masks())
            obs, reward, terminated, truncated, info = env.step(action)
            total_reward += float(reward)
            for key, value in info["reward_components"].items():
                component_totals[key] = component_totals.get(key, 0.0) + float(value)
            done = bool(terminated or truncated)
    finally:
        env.close()
    _write_json(args.output.resolve() / "evaluation.json", {
        "created_at": _utc_now(), "checkpoint": str(Path(args.checkpoint).resolve()),
        "requested_device": args.device, "resolved_device": device,
        "signal_count": env.signal_count,
        "action_count_per_signal": env.action_space.nvec.tolist()[0],
        "seed": args.seed, "run_dir": reset_info["run_dir"],
        "route_file": reset_info["route_file"],
        "simulation_time_s": info["time_s"], "reward_total": total_reward,
        "reward_components": component_totals,
        "arrivals": len(env._arrived_ids), "active_at_end": env._final_active_count,
        "due_pending_at_end": env._final_due_pending_count,
        "terminated": bool(terminated), "truncated": bool(truncated),
    })
    return 0


def parse_args(argv: list[str] | None = None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("train", "evaluate"), help="Evaluate optionally in a visible SUMO-GUI window")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--episode-output", type=Path, default=DEFAULT_OUTPUT / "episodes")
    parser.add_argument("--network", type=Path)
    parser.add_argument("--catalog", type=Path)
    parser.add_argument("--routes", type=Path)
    parser.add_argument("--training-routes", nargs="+", type=Path,
                        help="Choose one route file per training episode using the seeded environment RNG")
    parser.add_argument("--timing-profile", type=Path)
    parser.add_argument("--checkpoint", type=Path)
    parser.add_argument("--resume", type=Path, help="warm-start from checkpoint; not exact SUMO/RNG continuation")
    parser.add_argument("--gui", action="store_true", help="Show SUMO-GUI during evaluation")
    parser.add_argument("--gui-delay-ms", type=int, default=0, help="Delay between SUMO GUI steps; 0 runs at maximum speed")
    parser.add_argument("--gui-settings-file", type=Path, help="Optional SUMO-GUI view settings XML")
    parser.add_argument("--seed", type=int, default=4172026)
    parser.add_argument("--n-envs", type=int, default=1,
                        help="Número de SUMO headless independentes em paralelo para treino")
    parser.add_argument("--episode-horizon", type=float, default=600.0)
    parser.add_argument("--total-timesteps", type=int, default=4096)
    parser.add_argument("--checkpoint-every", type=int, default=2048)
    parser.add_argument("--rollout-steps", type=int, default=128)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--gamma", type=float, default=0.99)
    parser.add_argument("--gae-lambda", type=float, default=0.95)
    parser.add_argument("--clip-range", type=float, default=0.2)
    parser.add_argument("--entropy", type=float, default=0.01)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto",
                        help="Onde ficam os pesos/cálculos PPO; SUMO continua usando CPU")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    if args.mode == "evaluate":
        return evaluate(args)
    return train(args)


if __name__ == "__main__":
    raise SystemExit(main())

"""Safety-gated SUMO signal transitions shared by baseline and future agents.

The controller never synthesizes a red/yellow/green state vector. It only selects
phase indexes already present in the imported SUMO program, never shortens yellow
or all-red clearance, and may extend all-red only while waiting for a safe release.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Protocol


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_C2_DIR = ROOT / "sumo" / "scenarios" / "fluxia_stage6_c2"
DEFAULT_NETWORK = DEFAULT_C2_DIR / "centro_fluxia_c2.net.xml"
DEFAULT_SIGNALS = DEFAULT_C2_DIR / "pilot_signals_211_c2.json"
DEFAULT_OUTPUT = DEFAULT_C2_DIR / "signal_transitions_c2.json"
DEFAULT_TIMING_PROFILE = DEFAULT_C2_DIR / "green_timing_profile_c2.json"
PHASE_TIMING_NOTE = (
    "Green decision limits come from the explicit FluxIA simulation experiment profile. They are "
    "not calibrated field limits or official CET safety-green values."
)


class SignalPlanError(ValueError):
    """Raised when a SUMO program cannot be safely represented by this controller."""


class InvalidSignalAction(ValueError):
    """Raised when a requested action is outside the current safety mask."""


@dataclass(frozen=True)
class PhaseSpec:
    index: int
    duration_s: float
    state: str


@dataclass(frozen=True)
class DestinationStatus:
    """Fresh shared observation for the receiving lanes of one green stage."""

    observed_capacity_fraction: float
    measurement_age_s: float
    consecutive_observed_full_samples: int
    predicted_capacity_fraction: float | None = None


@dataclass(frozen=True)
class GreenTransition:
    green_phase: int
    yellow_phases: tuple[int, ...]
    clearance_phase: int
    native_next_green_phase: int
    green_floor_s: float
    yellow_duration_s: float
    clearance_duration_s: float
    green_max_s: float | None = None

    @property
    def yellow_phase(self) -> int:
        """First protected yellow phase, retained for older display callers."""
        return self.yellow_phases[0]


@dataclass(frozen=True)
class SignalPlan:
    controller_id: str
    phases: tuple[PhaseSpec, ...]
    green_phases: tuple[int, ...]
    transitions: Mapping[int, GreenTransition]
    phase_timing_note: str = PHASE_TIMING_NOTE
    cet_plan_verified: bool = False
    green_safety_times_verified: bool = False

    @classmethod
    def from_signal_record(
        cls,
        signal: Mapping[str, Any],
        *,
        green_floor_overrides_s: Mapping[int, float] | None = None,
        green_max_overrides_s: Mapping[int, float] | None = None,
    ) -> "SignalPlan":
        controller_id = str(signal.get("controller_id", ""))
        raw_phases = signal.get("phases")
        if not controller_id or not isinstance(raw_phases, list) or not raw_phases:
            raise SignalPlanError("Controlador sem ID ou sem fases SUMO.")

        phases = tuple(
            PhaseSpec(index=i, duration_s=float(row["duration"]), state=str(row["state"]))
            for i, row in enumerate(raw_phases)
        )
        if any(p.duration_s <= 0 or not p.state for p in phases):
            raise SignalPlanError(f"{controller_id}: duração não positiva ou estado vazio.")

        derived_green = tuple(
            phase.index
            for phase in phases
            if "y" not in phase.state.lower() and any(ch in "Gg" for ch in phase.state)
        )
        declared_green = tuple(int(i) for i in signal.get("green_phase_indexes", ()))
        if not derived_green or set(derived_green) != set(declared_green):
            raise SignalPlanError(
                f"{controller_id}: fases verdes do catálogo não correspondem aos estados SUMO."
            )

        overrides = {int(k): float(v) for k, v in (green_floor_overrides_s or {}).items()}
        max_overrides = {int(k): float(v) for k, v in (green_max_overrides_s or {}).items()}
        transitions: dict[int, GreenTransition] = {}
        phase_count = len(phases)
        for green_index in derived_green:
            green = phases[green_index]
            old_green = {i for i, ch in enumerate(green.state) if ch in "Gg"}
            yellow_indexes: list[int] = []
            clearance_index: int | None = None
            for offset in range(1, phase_count + 1):
                candidate_index = (green_index + offset) % phase_count
                candidate = phases[candidate_index]
                candidate_state = candidate.state
                candidate_green = {i for i, ch in enumerate(candidate_state) if ch in "Gg"}
                if not candidate_green.issubset(old_green):
                    raise SignalPlanError(
                        f"{controller_id}: fase {candidate_index} acende um movimento novo antes da limpeza do verde {green_index}."
                    )
                if candidate_state and set(candidate_state.lower()) == {"r"}:
                    clearance_index = candidate_index
                    break
                if "y" in candidate_state.lower():
                    yellow_indexes.append(candidate_index)
                elif not candidate_green:
                    raise SignalPlanError(
                        f"{controller_id}: fase {candidate_index} interrompe a cadeia amarela antes do vermelho integral."
                    )

            if clearance_index is None or not yellow_indexes:
                raise SignalPlanError(
                    f"{controller_id}: verde {green_index} não tem amarelo(s) seguido(s) de vermelho integral."
                )

            for link_index in old_green:
                saw_yellow = False
                closed = False
                for yellow_index in yellow_indexes:
                    char = phases[yellow_index].state[link_index]
                    if char in "yY":
                        saw_yellow = True
                    elif char in "Gg":
                        if saw_yellow or closed:
                            raise SignalPlanError(
                                f"{controller_id}: linkIndex {link_index} volta a verde durante a transição {green_index}."
                            )
                    else:
                        if not saw_yellow:
                            raise SignalPlanError(
                                f"{controller_id}: linkIndex {link_index} fecha sem amarelo após o verde {green_index}."
                            )
                        closed = True
                if not saw_yellow:
                    raise SignalPlanError(
                        f"{controller_id}: linkIndex {link_index} não recebe amarelo antes da limpeza."
                    )

            next_green_index = next(
                (
                    (clearance_index + offset) % phase_count
                    for offset in range(1, phase_count + 1)
                    if (clearance_index + offset) % phase_count in derived_green
                ),
                None,
            )
            if next_green_index is None:
                raise SignalPlanError(f"{controller_id}: não há verde depois da limpeza {clearance_index}.")

            floor_s = overrides.get(green_index, green.duration_s)
            maximum_s = max_overrides.get(green_index)
            if floor_s < 0 or floor_s > green.duration_s + 1e-9:
                raise SignalPlanError(
                    f"{controller_id}: piso verde {floor_s} da fase {green_index} deve estar entre 0 e "
                    f"a duração nominal SUMO {green.duration_s}."
                )
            if maximum_s is not None and maximum_s < floor_s:
                raise SignalPlanError(
                    f"{controller_id}: máximo verde {maximum_s} da fase {green_index} é menor que o piso {floor_s}."
                )
            transitions[green_index] = GreenTransition(
                green_phase=green_index,
                yellow_phases=tuple(yellow_indexes),
                clearance_phase=clearance_index,
                native_next_green_phase=next_green_index,
                green_floor_s=floor_s,
                yellow_duration_s=sum(phases[i].duration_s for i in yellow_indexes),
                clearance_duration_s=phases[clearance_index].duration_s,
                green_max_s=maximum_s,
            )

        return cls(
            controller_id=controller_id,
            phases=phases,
            green_phases=derived_green,
            transitions=transitions,
        )

    def phase_for_state(self, state: str) -> int | None:
        """Return an existing phase index with this exact state vector, if any."""
        return next((phase.index for phase in self.phases if phase.state == state), None)


@dataclass(frozen=True)
class SignalAction:
    kind: str
    target_green_phase: int | None = None
    duration_s: float | None = None

    @property
    def key(self) -> str:
        if self.target_green_phase is None:
            suffix = self.kind
        else:
            suffix = f"{self.kind}:{self.target_green_phase}"
        if self.duration_s is not None:
            suffix += f"@{self.duration_s:g}s"
        return suffix


class TrafficLightAPI(Protocol):
    def setPhase(self, tls_id: str, phase_index: int) -> None: ...
    def setPhaseDuration(self, tls_id: str, duration: float) -> None: ...


class SignalTransitionController:
    """Pure action mask plus a narrow TraCI adapter for one controller."""

    def __init__(
        self,
        plan: SignalPlan,
        *,
        epsilon_s: float = 1e-6,
        blocked_threshold: float = 0.95,
        blocked_confirmation_samples: int = 2,
        max_measurement_age_s: float = 6.0,
    ) -> None:
        self.plan = plan
        self.epsilon_s = epsilon_s
        self.blocked_threshold = float(blocked_threshold)
        self.blocked_confirmation_samples = int(blocked_confirmation_samples)
        self.max_measurement_age_s = float(max_measurement_age_s)
        self.events: list[dict[str, Any]] = []
        self._last_phase_index: int | None = None
        self._phase_entered_at_s: float | None = None
        self._request_sequence = 0
        self._pending_request: dict[str, Any] | None = None

    def observe_phase(self, phase_index: int, now_s: float) -> float:
        """Track elapsed time in the current phase, including after TraCI duration overrides."""
        if phase_index != self._last_phase_index:
            self._last_phase_index = phase_index
            self._phase_entered_at_s = float(now_s)
        if self._phase_entered_at_s is None:
            self._phase_entered_at_s = float(now_s)
        return max(0.0, float(now_s) - self._phase_entered_at_s)

    def _mark_phase(self, phase_index: int, now_s: float | None) -> None:
        self._last_phase_index = phase_index
        self._phase_entered_at_s = None if now_s is None else float(now_s)

    def _transition_for_yellow(self, phase_index: int) -> GreenTransition | None:
        return next(
            (t for t in self.plan.transitions.values() if phase_index in t.yellow_phases),
            None,
        )

    def _transition_for_clearance(self, phase_index: int) -> GreenTransition | None:
        return next(
            (t for t in self.plan.transitions.values() if t.clearance_phase == phase_index),
            None,
        )

    def _destination_bucket(self, status: DestinationStatus | bool | None, *, data_fresh: bool) -> str:
        """Classify a receiver without allowing a forecast by itself to hard-block it."""
        if not data_fresh or not isinstance(status, DestinationStatus):
            return "unknown"
        observed = float(status.observed_capacity_fraction)
        predicted = status.predicted_capacity_fraction
        age = float(status.measurement_age_s)
        if (
            not math.isfinite(observed)
            or not math.isfinite(age)
            or observed < 0
            or age < 0
            or age > self.max_measurement_age_s
            or (predicted is not None and (not math.isfinite(float(predicted)) or float(predicted) < 0))
            or status.consecutive_observed_full_samples < 0
        ):
            return "unknown"
        observed_full = observed >= self.blocked_threshold
        if observed_full:
            if status.consecutive_observed_full_samples >= self.blocked_confirmation_samples:
                return "blocked"
            return "pending_confirmation"
        forecast_risk = predicted is not None and float(predicted) >= self.blocked_threshold
        if observed_full or forecast_risk:
            return "at_risk"
        return "open"

    def allowed_actions(
        self,
        *,
        phase_index: int,
        phase_elapsed_s: float,
        data_fresh: bool,
        downstream_blocked_by_green: Mapping[int, DestinationStatus | bool | None] | None = None,
        simulation_step_s: float = 1.0,
    ) -> tuple[SignalAction, ...]:
        """Build the action mask; unknown or stale downstream data selects native fallback."""
        if phase_index < 0 or phase_index >= len(self.plan.phases):
            return (SignalAction("follow_native"),)
        if phase_elapsed_s < -self.epsilon_s:
            return (SignalAction("follow_native"),)

        if phase_index in self.plan.transitions:
            transition = self.plan.transitions[phase_index]
            if not data_fresh:
                return (SignalAction("follow_native"),)
            elapsed = max(0.0, phase_elapsed_s)
            actions: list[SignalAction] = []
            if transition.green_max_s is None or elapsed + self.epsilon_s < transition.green_max_s:
                actions.append(SignalAction("maintain_green"))
            if elapsed + self.epsilon_s >= transition.green_floor_s:
                actions.append(SignalAction("request_yellow"))
                if transition.green_max_s is not None and elapsed + self.epsilon_s < transition.green_max_s:
                    # SUMO evaluates phase changes on simulation-step boundaries.
                    # Leave one step of headroom so a no-decision run cannot cross
                    # the configured experimental cap by one full step.
                    extension_s = max(
                        0.0,
                        transition.green_max_s - elapsed - max(0.0, float(simulation_step_s)),
                    )
                    if extension_s > self.epsilon_s:
                        actions.append(SignalAction("extend_green_to_max", duration_s=round(extension_s, 6)))
            if not actions:
                return (SignalAction("follow_native"),)
            return tuple(actions)

        if self._transition_for_yellow(phase_index) is not None:
            return (SignalAction("continue_transition"),)

        clearance_transition = self._transition_for_clearance(phase_index)
        if clearance_transition is not None:
            buckets = {
                green: self._destination_bucket(
                    None if downstream_blocked_by_green is None else downstream_blocked_by_green.get(green),
                    data_fresh=data_fresh,
                )
                for green in self.plan.green_phases
            }
            statuses_are_complete = all(bucket != "unknown" for bucket in buckets.values())
            all_blocked = statuses_are_complete and all(bucket == "blocked" for bucket in buckets.values())
            confirmation_pending = (
                statuses_are_complete
                and any(bucket == "pending_confirmation" for bucket in buckets.values())
                and all(bucket in {"blocked", "pending_confirmation"} for bucket in buckets.values())
            )
            if phase_elapsed_s + self.epsilon_s < clearance_transition.clearance_duration_s:
                at_boundary = (
                    phase_elapsed_s + max(0.0, simulation_step_s) + self.epsilon_s
                    >= clearance_transition.clearance_duration_s
                )
                if at_boundary and statuses_are_complete and all_blocked:
                    return (SignalAction("hold_all_red"),)
                if at_boundary and confirmation_pending:
                    return (SignalAction("hold_for_confirmation"),)
                if at_boundary and statuses_are_complete:
                    # Add one simulation step so a non-native safe target can be
                    # selected after, never before, the configured clearance.
                    return (SignalAction("prepare_clearance_boundary"),)
                return (SignalAction("continue_transition"),)
            if not data_fresh or downstream_blocked_by_green is None:
                return (SignalAction("follow_native"),)
            if not statuses_are_complete:
                return (SignalAction("follow_native"),)
            if all_blocked:
                return (SignalAction("hold_all_red"),)
            if confirmation_pending:
                return (SignalAction("hold_for_confirmation"),)
            open_targets = [green for green, bucket in buckets.items() if bucket == "open"]
            # Predicted-only risk never creates an all-red lock. If every receiver is
            # forecast at risk, expose those candidates and let the rule/agent pick
            # the least risky one after the protected yellow and clearance.
            allowed_targets = open_targets or [green for green, bucket in buckets.items() if bucket == "at_risk"]
            return tuple(SignalAction("release_green", target) for target in allowed_targets)

        return (SignalAction("follow_native"),)

    def choose_fair_release(
        self,
        actions: Iterable[SignalAction],
        waiting_s_by_green: Mapping[int, float] | None = None,
        destination_status_by_green: Mapping[int, DestinationStatus | bool | None] | None = None,
    ) -> SignalAction:
        """Choose the longest-waiting safe green; break ties by phase index."""
        releases = [action for action in actions if action.kind == "release_green"]
        if not releases:
            raise InvalidSignalAction("A máscara atual não permite liberar uma fase verde.")
        waiting = waiting_s_by_green or {}
        if destination_status_by_green:
            buckets = {
                action.target_green_phase: self._destination_bucket(
                    destination_status_by_green.get(int(action.target_green_phase)),
                    data_fresh=True,
                )
                for action in releases
            }
            open_actions = [a for a in releases if buckets.get(a.target_green_phase) == "open"]
            if open_actions:
                releases = open_actions
            else:
                risk_scores: dict[int | None, float] = {}
                for action in releases:
                    status = destination_status_by_green.get(int(action.target_green_phase))
                    if isinstance(status, DestinationStatus):
                        predicted = status.predicted_capacity_fraction
                        risk_scores[action.target_green_phase] = max(
                            float(status.observed_capacity_fraction),
                            float(status.observed_capacity_fraction if predicted is None else predicted),
                        )
                if risk_scores:
                    least_risk = min(risk_scores.values())
                    releases = [a for a in releases if risk_scores.get(a.target_green_phase, float("inf")) <= least_risk + self.epsilon_s]
        return min(
            releases,
            key=lambda action: (-float(waiting.get(int(action.target_green_phase), 0.0)), int(action.target_green_phase)),
        )

    def apply_action(
        self,
        *,
        tls_id: str,
        traci_trafficlight: TrafficLightAPI,
        action: SignalAction,
        phase_index: int,
        phase_elapsed_s: float,
        data_fresh: bool,
        downstream_blocked_by_green: Mapping[int, DestinationStatus | bool | None] | None = None,
        simulation_step_s: float = 1.0,
        now_s: float | None = None,
    ) -> None:
        """Apply only a currently masked action using existing SUMO phase indexes."""
        mask = self.allowed_actions(
            phase_index=phase_index,
            phase_elapsed_s=phase_elapsed_s,
            data_fresh=data_fresh,
            downstream_blocked_by_green=downstream_blocked_by_green,
            simulation_step_s=simulation_step_s,
        )
        if action not in mask:
            raise InvalidSignalAction(
                f"Ação {action.key} não permitida para {tls_id}, fase {phase_index}; "
                f"permitidas: {[item.key for item in mask]}"
            )

        target_phase = phase_index
        if action.kind == "request_yellow":
            transition = self.plan.transitions[phase_index]
            target_phase = transition.yellow_phase
            traci_trafficlight.setPhase(tls_id, target_phase)
            self._mark_phase(target_phase, now_s)
            self._request_sequence += 1
            request_id = f"{tls_id}-request-{self._request_sequence:04d}"
            self._pending_request = {
                "request_id": request_id,
                "origin_green_phase": phase_index,
                "requested_at_s": None if now_s is None else float(now_s),
            }
        elif action.kind == "release_green":
            assert action.target_green_phase is not None
            target_phase = action.target_green_phase
            traci_trafficlight.setPhase(tls_id, target_phase)
            self._mark_phase(target_phase, now_s)
        elif action.kind in {"hold_all_red", "hold_for_confirmation"}:
            transition = self._transition_for_clearance(phase_index)
            assert transition is not None
            extension = max(2.0 * float(simulation_step_s), float(simulation_step_s))
            traci_trafficlight.setPhaseDuration(tls_id, extension)
        elif action.kind == "prepare_clearance_boundary":
            if self._transition_for_clearance(phase_index) is None or simulation_step_s <= 0:
                raise InvalidSignalAction("A extensão de borda só pode ocorrer em vermelho integral.")
            traci_trafficlight.setPhaseDuration(tls_id, 2.0 * float(simulation_step_s))
        elif action.kind == "extend_green_to_max":
            if action.duration_s is None or action.duration_s <= 0:
                raise InvalidSignalAction("A extensão precisa ter duração positiva e limitada.")
            traci_trafficlight.setPhaseDuration(tls_id, action.duration_s)
        elif action.kind == "follow_native":
            if phase_index in self.plan.transitions:
                transition = self.plan.transitions[phase_index]
                nominal_green = self.plan.phases[phase_index].duration_s
                remaining = nominal_green - max(0.0, phase_elapsed_s)
                if remaining <= self.epsilon_s:
                    target_phase = transition.yellow_phase
                    traci_trafficlight.setPhase(tls_id, target_phase)
                    self._mark_phase(target_phase, now_s)
                else:
                    traci_trafficlight.setPhaseDuration(
                        tls_id,
                        max(float(simulation_step_s), remaining),
                    )
            else:
                transition = self._transition_for_clearance(phase_index)
                if transition is not None:
                    remaining = transition.clearance_duration_s - max(0.0, phase_elapsed_s)
                    if remaining <= self.epsilon_s:
                        target_phase = transition.native_next_green_phase
                        traci_trafficlight.setPhase(tls_id, target_phase)
                        self._mark_phase(target_phase, now_s)
                    else:
                        traci_trafficlight.setPhaseDuration(
                            tls_id,
                            max(float(simulation_step_s), remaining),
                        )

        event = {
                "time_s": None if now_s is None else round(float(now_s), 3),
                "controller_id": tls_id,
                "from_phase": phase_index,
                "action": action.key,
                "to_phase": target_phase,
                "state_vector": self.plan.phases[target_phase].state,
                "phase_state_source": "existing SUMO program phase index",
            }
        if action.kind == "request_yellow":
            event.update(
                {
                    "request_id": self._pending_request["request_id"],
                    "request_execution": "yellow_started",
                    "green_destination_selected": False,
                    "clearance_policy": "re_evaluate_fresh_capacity_after_clearance",
                }
            )
        elif action.kind == "release_green":
            pending_request = self._pending_request
            event["request_id"] = None if pending_request is None else pending_request["request_id"]
            event["destination_selection"] = "fresh_capacity_after_clearance"
            event["request_resolution"] = (
                "re_evaluated_and_released" if pending_request is not None else "no_pending_yellow_request"
            )
            event["request_origin_green_phase"] = (
                None if pending_request is None else pending_request["origin_green_phase"]
            )
            self._pending_request = None
        elif action.kind == "follow_native" and phase_index not in self.plan.transitions:
            pending_request = self._pending_request
            event["request_id"] = None if pending_request is None else pending_request["request_id"]
            event["request_resolution"] = (
                "cancelled_native_fallback" if pending_request is not None else "no_pending_yellow_request"
            )
            self._pending_request = None
        elif self._pending_request is not None:
            event["request_id"] = self._pending_request["request_id"]
            event["request_resolution"] = "pending_until_clearance_and_fresh_capacity"
        self.events.append(event)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_timing_profile(profile_path: Path = DEFAULT_TIMING_PROFILE) -> dict[str, Any]:
    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    green = profile.get("green", {})
    minimum = float(green.get("decision_minimum_s", 0))
    maximum = float(green.get("maximum_s", 0))
    blocking = profile.get("downstream_blocking", {})
    if minimum <= 0 or maximum < minimum:
        raise SignalPlanError("O perfil de controle verde precisa ter mínimo positivo e máximo >= mínimo.")
    if float(blocking.get("observed_capacity_fraction_threshold", 0)) <= 0:
        raise SignalPlanError("O perfil precisa definir um limite de capacidade observado positivo.")
    if int(blocking.get("blocked_confirmation_samples", 0)) < 2:
        raise SignalPlanError("Bloqueio real precisa de pelo menos duas observações consecutivas.")
    return profile


def plan_from_profile(
    signal: Mapping[str, Any],
    profile: Mapping[str, Any],
) -> SignalPlan:
    green_profile = profile["green"]
    decision_minimum = float(green_profile["decision_minimum_s"])
    maximum = float(green_profile["maximum_s"])
    phases = signal.get("phases", [])
    floors = {
        int(index): min(decision_minimum, float(phases[int(index)]["duration"]))
        for index in signal.get("green_phase_indexes", ())
    }
    maxima = {int(index): maximum for index in signal.get("green_phase_indexes", ())}
    return SignalPlan.from_signal_record(
        signal,
        green_floor_overrides_s=floors,
        green_max_overrides_s=maxima,
    )


def controller_from_profile(
    signal: Mapping[str, Any],
    profile: Mapping[str, Any],
) -> SignalTransitionController:
    blocking = profile["downstream_blocking"]
    return SignalTransitionController(
        plan_from_profile(signal, profile),
        blocked_threshold=float(blocking["observed_capacity_fraction_threshold"]),
        blocked_confirmation_samples=int(blocking["blocked_confirmation_samples"]),
        max_measurement_age_s=float(blocking["maximum_measurement_age_s"]),
    )


def build_transition_catalog(
    signals_path: Path = DEFAULT_SIGNALS,
    network_path: Path = DEFAULT_NETWORK,
    output_path: Path = DEFAULT_OUTPUT,
    profile_path: Path = DEFAULT_TIMING_PROFILE,
) -> dict[str, Any]:
    source = json.loads(signals_path.read_text(encoding="utf-8"))
    records = source.get("signals", [])
    profile = load_timing_profile(profile_path)
    plans = [plan_from_profile(row, profile) for row in records]
    transitions = []
    for plan in plans:
        for green_index, transition in sorted(plan.transitions.items()):
            transitions.append(
                {
                    "controller_id": plan.controller_id,
                    "green_phase": green_index,
                    "green_state": plan.phases[green_index].state,
                    "green_nominal_duration_s": plan.phases[green_index].duration_s,
                    "green_action_floor_s": transition.green_floor_s,
                    "green_floor_source": f"{profile['profile_id']}; experiment-only decision floor, not verified CET safety green",
                    "green_max_s": transition.green_max_s,
                    "green_max_source": f"{profile['profile_id']}; experiment-only cap, not a verified CET maximum",
                    "yellow_phase": transition.yellow_phase,
                    "yellow_phase_indexes": list(transition.yellow_phases),
                    "yellow_states": [plan.phases[i].state for i in transition.yellow_phases],
                    "yellow_phase_durations_s": [plan.phases[i].duration_s for i in transition.yellow_phases],
                    "yellow_duration_s": transition.yellow_duration_s,
                    "clearance_phase": transition.clearance_phase,
                    "clearance_state": plan.phases[transition.clearance_phase].state,
                    "clearance_duration_s": transition.clearance_duration_s,
                    "native_next_green_phase": transition.native_next_green_phase,
                    "permitted_target_green_phases": list(plan.green_phases),
                }
            )
    payload = {
        "schema_version": 1,
        "scope": "simulation_only",
        "controller_count": len(plans),
        "green_transition_count": len(transitions),
        "source": {
            "network_file": str(network_path.resolve()),
            "network_sha256": sha256_file(network_path),
            "signal_catalog_file": str(signals_path.resolve()),
            "signal_catalog_sha256": sha256_file(signals_path),
            "timing_profile_file": str(profile_path.resolve()),
            "timing_profile_sha256": sha256_file(profile_path),
            "timing_verification": "Imported SUMO program; intersection-specific CET plan not verified.",
        },
        "safety_contract": {
            "yellow": "Agent cannot change phase duration or skip it; SUMO program duration is preserved.",
            "red_clearance": "All-red phase and its duration are preserved; hold can only extend it.",
            "green_floor": profile["green"],
            "green_maximum": profile["green"]["maximum_s"],
            "green_safety_seconds": "unknown until CET plan values are obtained",
            "official_green_maximum_seconds": "unknown until CET plan values are obtained",
            "movement_compatibility": "Only phase indexes and state vectors already in the imported SUMO program can be selected; no state vector is synthesized.",
            "stale_or_missing_data": "Follow the existing SUMO program.",
            "downstream_blocking": profile["downstream_blocking"],
            "all_destinations_blocked": "Hold all-red only when every destination is confirmed full by fresh repeated observations; predictions alone cannot create an all-red lock.",
        },
        "action_contract": {
            "green": ["maintain_green", "request_yellow after configured floor; no destination is selected yet", "extend_green_to_max only within the experimental cap"],
            "yellow": ["continue_transition through every phase in the protected yellow chain"],
            "clearance": ["continue_transition", "release_green(target_phase) when safe", "hold_all_red only when every destination is blocked", "follow_native when data is stale or incomplete"],
            "request_resolution": "A request begins the yellow chain; destination capacity is re-evaluated with fresh data after the complete all-red clearance. Events record release or native-fallback cancellation.",
            "phase_state_mutation": "forbidden; use validated setPhase indexes only",
        },
        "transitions": transitions,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return payload


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--signals", type=Path, default=DEFAULT_SIGNALS)
    parser.add_argument("--network", type=Path, default=DEFAULT_NETWORK)
    parser.add_argument("--profile", type=Path, default=DEFAULT_TIMING_PROFILE)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    payload = build_transition_catalog(
        args.signals.resolve(), args.network.resolve(), args.output.resolve(), args.profile.resolve()
    )
    print(
        f"controllers={payload['controller_count']} transitions={payload['green_transition_count']} "
        f"output={args.output.resolve()}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Gymnasium bridge from simultaneous FluxIA actions to a protected SUMO episode.

Each step applies one masked subaction for every configured signal, then advances
five SUMO ticks. Yellow, all-red, conflict checks, and fallback actions stay in
the C2 transition controller.
"""

from __future__ import annotations

import json
import math
import uuid
import xml.etree.ElementTree as ET
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import gymnasium as gym
import numpy as np
import traci
from gymnasium import spaces

if __package__:
    from .fluxia_observations import ObservationService, SignalTopology
    from .fluxia_signal_control import (
        DestinationStatus,
        SignalAction,
        controller_from_profile,
        load_timing_profile,
    )
    from .run_fluxia_executor import discover_sumo, edge_fraction, sha256, write_json
else:
    from fluxia_observations import ObservationService, SignalTopology
    from fluxia_signal_control import (
        DestinationStatus,
        SignalAction,
        controller_from_profile,
        load_timing_profile,
    )
    from run_fluxia_executor import discover_sumo, edge_fraction, sha256, write_json


ROOT = Path(__file__).resolve().parents[1]
C2 = ROOT / "sumo" / "scenarios" / "fluxia_stage6_c2"
DEFAULT_NETWORK = C2 / "centro_fluxia_c2.net.xml"
DEFAULT_CATALOG = C2 / "pilot_signals_8_c2.json"
DEFAULT_PROFILE = C2 / "green_timing_profile_c2.json"
DEFAULT_ROUTES = ROOT / "docs" / "execucao-luna" / "inputs" / "c5" / "frozen_scenarios" / "training" / "estresse" / "demand.rou.xml"
DEFAULT_OUTPUT = ROOT / "docs" / "execucao-luna" / "outputs" / "stage10"
ACTION_COUNT = 6
FEATURE_COUNT = 16


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _read_scheduled(routes: Path) -> list[tuple[float, str]]:
    return [
        (float(row.get("depart", "0")), str(row.get("id", "")))
        for row in ET.parse(routes).getroot().findall("vehicle")
    ]


def _clip01(value: float) -> float:
    return float(min(1.0, max(0.0, value))) if math.isfinite(float(value)) else 0.0


class FluxIASumoEnv(gym.Env):
    """One network-level PPO policy returns simultaneous actions for its catalog."""

    metadata = {"render_modes": []}

    def __init__(
        self,
        *,
        network: Path = DEFAULT_NETWORK,
        catalog: Path = DEFAULT_CATALOG,
        routes: Path = DEFAULT_ROUTES,
        route_candidates: list[Path] | None = None,
        timing_profile: Path = DEFAULT_PROFILE,
        output_root: Path = DEFAULT_OUTPUT,
        end_time_s: float = 600.0,
        sumo_step_s: float = 0.2,
        decision_period_s: float = 1.0,
        prediction_horizon_s: float = 30.0,
        teleport_s: float = -1.0,
        seed: int = 4172026,
        gui: bool = False,
        gui_delay_ms: int = 0,
        gui_settings_file: Path | None = None,
    ) -> None:
        super().__init__()
        self.network = Path(network).resolve()
        self.catalog = Path(catalog).resolve()
        requested_routes = Path(routes).resolve()
        self.route_candidates = [Path(row).resolve() for row in route_candidates] if route_candidates else [requested_routes]
        if not self.route_candidates or len(set(self.route_candidates)) != len(self.route_candidates):
            raise ValueError("Training route candidates must be a non-empty list of unique files")
        self.routes = self.route_candidates[0]
        self.timing_profile_path = Path(timing_profile).resolve()
        self.output_root = Path(output_root).resolve()
        self.end_time_s = float(end_time_s)
        self.sumo_step_s = float(sumo_step_s)
        self.decision_period_s = float(decision_period_s)
        self.prediction_horizon_s = float(prediction_horizon_s)
        self.teleport_s = float(teleport_s)
        self.default_seed = int(seed)
        self.gui = bool(gui)
        self.gui_delay_ms = int(gui_delay_ms)
        self.gui_settings_file = Path(gui_settings_file).resolve() if gui_settings_file else None
        if self.gui_delay_ms < 0:
            raise ValueError("gui_delay_ms must be non-negative")
        if self.end_time_s <= 0 or self.sumo_step_s <= 0 or self.decision_period_s <= 0:
            raise ValueError("Episode horizon and time steps must be positive")
        ratio = self.decision_period_s / self.sumo_step_s
        if not math.isclose(ratio, round(ratio), abs_tol=1e-8):
            raise ValueError("decision_period_s must be an integer multiple of sumo_step_s")
        if not math.isclose(self.end_time_s / self.decision_period_s, round(self.end_time_s / self.decision_period_s), abs_tol=1e-8):
            raise ValueError("end_time_s must be an integer multiple of decision_period_s")
        for path in (self.network, self.catalog, self.timing_profile_path, *self.route_candidates):
            if not path.is_file():
                raise FileNotFoundError(path)

        payload = json.loads(self.catalog.read_text(encoding="utf-8"))
        self.signal_rows = payload["signals"]
        self.signal_ids = [str(row["controller_id"]) for row in self.signal_rows]
        self.signal_count = len(self.signal_ids)
        if self.signal_count == 0 or len(set(self.signal_ids)) != self.signal_count:
            raise ValueError("Signal catalog must contain unique controller IDs")
        self.topology = SignalTopology(self.network, self.catalog)
        self.profile = load_timing_profile(self.timing_profile_path)
        self.controllers = {
            str(row["controller_id"]): controller_from_profile(row, self.profile)
            for row in self.signal_rows
        }
        self.green_links: dict[str, dict[int, set[int]]] = {}
        self.green_edges: dict[str, dict[int, set[str]]] = {}
        for tls_id, controller in self.controllers.items():
            self.green_links[tls_id] = {}
            self.green_edges[tls_id] = {}
            for green_phase in controller.plan.green_phases:
                state = controller.plan.phases[green_phase].state
                links = {index for index, value in enumerate(state) if value in "Gg"}
                edges = {
                    str(movement["receiver_edge_id"])
                    for link in links
                    for movement in self.topology.movements_by_link.get((tls_id, link), [])
                }
                self.green_links[tls_id][green_phase] = links
                self.green_edges[tls_id][green_phase] = edges
        self.max_green_stages = max(len(controller.plan.green_phases) for controller in self.controllers.values())
        self.action_count = max(ACTION_COUNT, 3 + self.max_green_stages)
        self.receiver_edge_ids = {
            edge_id
            for row in self.green_edges.values()
            for edge_ids in row.values()
            for edge_id in edge_ids
        }
        self.scheduled = _read_scheduled(self.routes)
        self.action_space = spaces.MultiDiscrete(np.full(self.signal_count, self.action_count, dtype=np.int64))
        self.observation_space = spaces.Box(
            low=0.0, high=1.0, shape=(self.signal_count, FEATURE_COUNT), dtype=np.float32,
        )
        self._connection: Any = None
        self._stdout: Any = None
        self._service: ObservationService | None = None
        self._run_dir: Path | None = None
        self._action_stream: Any = None
        self._reward_stream: Any = None
        self._phase_stream: Any = None
        self._seed = self.default_seed
        self._sim_time_s = 0.0
        self._latest_snapshot: dict[str, Any] | None = None
        self._latest_observations: dict[str, dict[str, Any]] = {}
        self._statuses: dict[str, dict[int, DestinationStatus | None]] = {}
        self._details: dict[str, dict[int, dict[str, Any]]] = {}
        self._waiting_since: dict[tuple[str, int], float] = {}
        self._status_history: dict[tuple[str, int], dict[str, Any]] = defaultdict(
            lambda: {"snapshot_id": None, "consecutive_full": 0}
        )
        self._phase_index: dict[str, int] = {}
        self._phase_state: dict[str, str] = {}
        self._wait_phase_index: dict[str, int] = {}
        self._action_maps: list[dict[int, SignalAction]] = [{} for _ in self.signal_ids]
        self._mask = np.zeros(self.signal_count * self.action_count, dtype=np.bool_)
        self._departed_ids: set[str] = set()
        self._arrived_ids: set[str] = set()
        self._teleport_ids: set[str] = set()
        self._collision_vehicle_count = 0
        self._step_count = 0
        self._decision_log: list[dict[str, Any]] = []
        self._reward_totals: dict[str, float] = defaultdict(float)
        self._natural_terminal = False
        self._closed = True
        self._final_active_count = 0
        self._final_due_pending_count = 0
        self._last_executed_actions: list[dict[str, Any]] = []
        self._gui_view_id: str | None = None
        self._gui_tracked_vehicle: str | None = None
        self._gui_preview_path: Path | None = None
        self._gui_preview_scheduled = False

    def _start_sumo(self) -> None:
        sim_binary = discover_sumo(self.gui)
        version = traci.__version__
        self._run_id = f"rl_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}_{uuid.uuid4().hex[:6]}"
        self._run_dir = self.output_root / self._run_id
        self._run_dir.mkdir(parents=True, exist_ok=False)
        self._stdout = (self._run_dir / "sumo_stdout.log").open("w", encoding="utf-8", errors="replace")
        command = [
            str(sim_binary), "--net-file", str(self.network), "--route-files", str(self.routes),
            "--begin", "0", "--end", f"{self.end_time_s:g}",
            "--step-length", f"{self.sumo_step_s:g}", "--seed", str(self._seed),
            "--no-step-log", "--duration-log.statistics", "--time-to-teleport", f"{self.teleport_s:g}",
            "--tripinfo-output", str(self._run_dir / "tripinfo.xml"),
            "--tripinfo-output.write-unfinished", "--tripinfo-output.write-undeparted",
            "--collision-output", str(self._run_dir / "collisions.xml"),
            "--collision.check-junctions", "--summary-output", str(self._run_dir / "sumo_summary.xml"),
        ]
        if self.gui:
            command.extend(["--start", "--delay", str(self.gui_delay_ms), "--quit-on-end"])
            command.extend(["--window-size", "1400,900", "--window-pos", "0,0"])
            if self.gui_settings_file:
                command.extend(["--gui-settings-file", str(self.gui_settings_file)])
        traci.start(command, label=self._run_id, stdout=self._stdout, verbose=False)
        self._connection = traci.getConnection(self._run_id)
        self._gui_view_id = None
        self._gui_tracked_vehicle = None
        self._gui_preview_path = None
        self._gui_preview_scheduled = False
        if self.gui:
            view_ids = list(self._connection.gui.getIDList())
            if view_ids:
                self._gui_view_id = view_ids[0]
                self._gui_preview_path = self._run_dir / "gui_preview_midrun.png"
                # Start close enough for SUMO-GUI to render individual cars clearly.
                # The view will recenter on a live vehicle during the episode.
                self._connection.gui.setZoom(self._gui_view_id, 1800.0)
        self._service = ObservationService(
            self.topology, self._connection, horizon_seconds=self.prediction_horizon_s,
            active_signal_ids=set(self.signal_ids),
        )
        self._action_stream = (self._run_dir / "actions.jsonl").open("w", encoding="utf-8")
        self._reward_stream = (self._run_dir / "rewards.jsonl").open("w", encoding="utf-8")
        self._phase_stream = (self._run_dir / "phase_trace.jsonl").open("w", encoding="utf-8")
        write_json(self._run_dir / "execution_header.json", {
            "run_id": self._run_id,
            "mode": "gymnasium_random_or_external_policy",
            "seed": self._seed,
            "versions": {"traci": version, "sumo": str(sim_binary)},
            "network": {"path": str(self.network), "sha256": sha256(self.network)},
            "catalog": {"path": str(self.catalog), "sha256": sha256(self.catalog)},
            "routes": {"path": str(self.routes), "sha256": sha256(self.routes)},
            "route_candidates": [
                {"path": str(path), "sha256": sha256(path)} for path in self.route_candidates
            ],
            "timing_profile": {"path": str(self.timing_profile_path), "sha256": sha256(self.timing_profile_path)},
            "signals": self.signal_ids,
            "sumo_step_s": self.sumo_step_s,
            "decision_period_s": self.decision_period_s,
            "end_time_s": self.end_time_s,
            "teleport_s": self.teleport_s,
            "ui": "gui" if self.gui else "headless",
            "gui_delay_ms": self.gui_delay_ms if self.gui else None,
            "gui_settings_file": str(self.gui_settings_file) if self.gui_settings_file else None,
            "gui_view_id": self._gui_view_id,
                "gui_vehicle_display": "departed vehicles are highlighted magenta; viewport follows and centers an active vehicle",
            "gui_preview_path": str(self._gui_preview_path) if self._gui_preview_path else None,
            "signal_count": self.signal_count,
            "action_space": f"MultiDiscrete([{self.action_count}]*{self.signal_count}) with {self.signal_count * self.action_count}-entry per-decision C2 validity mask",
            "yellow_clearance": "C2 phases are immutable; only current masked actions are applied",
            "gymnasium": gym.__version__,
        })
        self._closed = False

    def _refresh(self) -> None:
        assert self._service is not None and self._connection is not None
        now = float(self._connection.simulation.getTime())
        self._sim_time_s = now
        self._latest_snapshot = self._service.sample(now)
        self._latest_observations = {
            tls_id: self._service.controller_observation(
                tls_id, self._latest_snapshot, include_forecasts=True, now_s=now,
            )
            for tls_id in self.signal_ids
        }
        self._statuses = {}
        self._details = {}
        for tls_id in self.signal_ids:
            self._statuses[tls_id] = {}
            self._details[tls_id] = {}
            for green_phase, edge_ids in self.green_edges[tls_id].items():
                observed, edge_rows = edge_fraction(self._latest_snapshot, edge_ids)
                forecast_values: list[float] = []
                for movement in self._latest_observations[tls_id].get("movements", []):
                    if int(movement.get("link_index", -1)) not in self.green_links[tls_id][green_phase]:
                        continue
                    for option in movement["downstream_options"]:
                        forecast = option.get("forecast") or {}
                        value = forecast.get("predicted_storage_fraction_estimate")
                        if isinstance(value, (float, int)) and math.isfinite(float(value)):
                            forecast_values.append(float(value))
                predicted = max(forecast_values) if forecast_values else None
                history = self._waiting_since
                if (tls_id, green_phase) not in history:
                    history[(tls_id, green_phase)] = 0.0
                self._details[tls_id][green_phase] = {
                    "edge_ids": sorted(edge_ids),
                    "edge_rows": edge_rows,
                    "vehicle_count": sum(int(row.get("vehicle_count", 0)) for row in edge_rows),
                    "capacity": sum(int(row.get("capacity_estimate_vehicles", 0)) for row in edge_rows),
                    "observed_fraction": observed,
                    "predicted_fraction": predicted,
                }
                history = self._status_history[(tls_id, green_phase)]
                snapshot_id = self._latest_snapshot["snapshot_id"]
                if history["snapshot_id"] != snapshot_id:
                    threshold = self.controllers[tls_id].blocked_threshold
                    history["consecutive_full"] = (
                        int(history["consecutive_full"]) + 1
                        if observed is not None and observed >= threshold else 0
                    )
                    history["snapshot_id"] = snapshot_id
                consecutive_full = int(history["consecutive_full"])
                self._statuses[tls_id][green_phase] = None if observed is None else DestinationStatus(
                    observed_capacity_fraction=float(observed),
                    measurement_age_s=0.0,
                    consecutive_observed_full_samples=consecutive_full,
                    predicted_capacity_fraction=predicted,
                )
            phase_index = int(self._connection.trafficlight.getPhase(tls_id))
            if self._wait_phase_index.get(tls_id) != phase_index:
                if phase_index in self.controllers[tls_id].plan.green_phases:
                    self._waiting_since[(tls_id, phase_index)] = now
                self._wait_phase_index[tls_id] = phase_index
        self._build_masks()

    def _fresh_for(self, tls_id: str) -> bool:
        return (
            self._latest_snapshot is not None
            and self._sim_time_s - float(self._latest_snapshot["time_s"])
            <= self.controllers[tls_id].max_measurement_age_s
        )

    def _build_masks(self) -> None:
        assert self._connection is not None
        self._mask = np.zeros(self.signal_count * self.action_count, dtype=np.bool_)
        self._action_maps = [{} for _ in self.signal_ids]
        for index, tls_id in enumerate(self.signal_ids):
            controller = self.controllers[tls_id]
            phase = int(self._connection.trafficlight.getPhase(tls_id))
            age = float(self._connection.trafficlight.getSpentDuration(tls_id))
            allowed = controller.allowed_actions(
                phase_index=phase,
                phase_elapsed_s=age,
                data_fresh=self._fresh_for(tls_id),
                downstream_blocked_by_green=self._statuses.get(tls_id, {}),
                simulation_step_s=self.sumo_step_s,
            )
            base = index * self.action_count
            releases = sorted(
                (action for action in allowed if action.kind == "release_green"),
                key=lambda action: int(action.target_green_phase or 0),
            )
            if releases:
                for rank, action in enumerate(releases):
                    action_index = 3 + rank
                    self._mask[base + action_index] = True
                    self._action_maps[index][action_index] = action
            elif phase in controller.plan.transitions:
                mapped = {
                    "maintain_green": 0,
                    "follow_native": 0,
                    "request_yellow": 1,
                    "extend_green_to_max": 2,
                }
                for action in allowed:
                    action_index = mapped.get(action.kind, 0)
                    self._mask[base + action_index] = True
                    self._action_maps[index][action_index] = action
            else:
                # Yellow, clearance and safety holds are environment interlocks.
                # The only agent choice here is a no-op; C2 advances the state.
                self._mask[base] = True
                deterministic = next((action for action in allowed if action.kind != "release_green"), None)
                if deterministic is not None:
                    self._action_maps[index][0] = deterministic
                elif allowed:
                    self._action_maps[index][0] = allowed[0]

    def action_masks(self) -> np.ndarray:
        """MaskablePPO expects one flattened bool array; True means legal."""
        return self._mask.copy()

    def _approach_lanes(self, tls_id: str, green_phase: int | None) -> set[str]:
        if green_phase is None or self._latest_snapshot is None:
            return set()
        return {
            str(movement["from_lane_id"])
            for link in self.green_links[tls_id][green_phase]
            for movement in self.topology.movements_by_link.get((tls_id, link), [])
        }

    def _observation(self) -> np.ndarray:
        assert self._connection is not None and self._latest_snapshot is not None
        matrix = np.zeros((self.signal_count, FEATURE_COUNT), dtype=np.float32)
        for index, tls_id in enumerate(self.signal_ids):
            controller = self.controllers[tls_id]
            phase_index = int(self._connection.trafficlight.getPhase(tls_id))
            phase_state = str(self._connection.trafficlight.getRedYellowGreenState(tls_id))
            phase_age = float(self._connection.trafficlight.getSpentDuration(tls_id))
            current_green = phase_index if phase_index in controller.plan.transitions else None
            transition = None
            if current_green is None:
                transition = controller._transition_for_yellow(phase_index)
                if transition is None:
                    transition = controller._transition_for_clearance(phase_index)
                if transition is not None:
                    current_green = transition.green_phase
            green_phases = list(controller.plan.green_phases)
            rank = green_phases.index(current_green) if current_green in green_phases else 0
            floor = controller.plan.transitions[current_green].green_floor_s if current_green is not None else 0.0
            links = set() if current_green is None else self.green_links[tls_id][current_green]
            lane_ids = self._approach_lanes(tls_id, current_green)
            lane_rows = [self._latest_snapshot["lane_states"].get(lane_id, {}) for lane_id in lane_ids]
            local_queue = sum(int(row.get("queue_vehicle_count", 0)) for row in lane_rows)
            speeds = [float(row["mean_speed_mps"]) for row in lane_rows if row.get("vehicle_count", 0) > 0]
            mean_speed = float(np.mean(speeds)) if speeds else 0.0
            current_status = self._statuses.get(tls_id, {}).get(current_green) if current_green is not None else None
            alternative = [
                status for green, status in self._statuses.get(tls_id, {}).items()
                if green != current_green and isinstance(status, DestinationStatus)
            ]
            alternative_observed = max((status.observed_capacity_fraction for status in alternative), default=0.0)
            alternative_predicted_values = [status.predicted_capacity_fraction for status in alternative if status.predicted_capacity_fraction is not None]
            alternative_predicted = max(alternative_predicted_values, default=0.0)
            alternative_waits = [
                max(0.0, self._sim_time_s - self._waiting_since.get((tls_id, green), 0.0))
                for green in green_phases if green != current_green
            ]
            detail = self._details.get(tls_id, {}).get(current_green, {}) if current_green is not None else {}
            neighbor_queue = max((int(row.get("queue_vehicle_count", 0)) for row in detail.get("edge_rows", [])), default=0)
            data_age = 0.0 if self._latest_snapshot is None else max(0.0, self._sim_time_s - float(self._latest_snapshot["time_s"]))
            if any(ch in phase_state.lower() for ch in "g"):
                phase_kind = 0.0
            elif "y" in phase_state.lower():
                phase_kind = 1.0 / 3.0
            elif phase_state and set(phase_state.lower()) == {"r"}:
                phase_kind = 2.0 / 3.0
            else:
                phase_kind = 1.0
            matrix[index] = np.array([
                phase_kind,
                rank / max(1, len(green_phases) - 1),
                _clip01(phase_age / 90.0),
                _clip01(max(0.0, floor - phase_age) / 90.0),
                _clip01(local_queue / 20.0),
                _clip01(mean_speed / 13.9),
                0.0 if current_status is None else _clip01(current_status.observed_capacity_fraction),
                float(current_status is not None and self._fresh_for(tls_id)),
                0.0 if current_status is None or current_status.predicted_capacity_fraction is None else _clip01(current_status.predicted_capacity_fraction),
                float(current_status is not None and current_status.predicted_capacity_fraction is not None and self._fresh_for(tls_id)),
                _clip01(alternative_observed),
                _clip01(alternative_predicted),
                _clip01(neighbor_queue / 20.0),
                _clip01(max(alternative_waits, default=0.0) / 120.0),
                _clip01(data_age / 6.0),
                _clip01(len(green_phases) / max(4.0, float(self.max_green_stages))),
            ], dtype=np.float32)
        return matrix

    def reset(self, *, seed: int | None = None, options: dict[str, Any] | None = None):
        super().reset(seed=seed)
        if not self._closed:
            self.close()
        candidate_index = int(self.np_random.integers(len(self.route_candidates)))
        self.routes = self.route_candidates[candidate_index]
        self.scheduled = _read_scheduled(self.routes)
        self._seed = self.default_seed if seed is None else int(seed)
        self._sim_time_s = 0.0
        self._departed_ids.clear()
        self._arrived_ids.clear()
        self._teleport_ids.clear()
        self._collision_vehicle_count = 0
        self._step_count = 0
        self._decision_log = []
        self._reward_totals = defaultdict(float)
        self._natural_terminal = False
        self._final_active_count = 0
        self._final_due_pending_count = 0
        self.controllers = {
            str(row["controller_id"]): controller_from_profile(row, self.profile)
            for row in self.signal_rows
        }
        self._status_history = defaultdict(lambda: {"snapshot_id": None, "consecutive_full": 0})
        self._waiting_since = {(tls_id, green): 0.0 for tls_id, c in self.controllers.items() for green in c.plan.green_phases}
        self._phase_index = {}
        self._phase_state = {}
        self._wait_phase_index = {}
        self._start_sumo()
        self._refresh()
        return self._observation(), {
            "time_s": self._sim_time_s, "run_dir": str(self._run_dir),
            "signal_ids": self.signal_ids, "route_file": str(self.routes),
        }

    def _due_pending(self) -> int:
        due_ids = {vehicle_id for depart, vehicle_id in self.scheduled if depart < self._sim_time_s - 1e-9}
        return max(0, len(due_ids - self._departed_ids))

    def step(self, action: np.ndarray):
        if self._closed or self._connection is None:
            raise RuntimeError("Call reset() before step() and do not step after close().")
        action_values = np.asarray(action, dtype=np.int64).reshape(self.signal_count)
        executed_rows: list[dict[str, Any]] = []
        held_count = 0
        for index, tls_id in enumerate(self.signal_ids):
            controller = self.controllers[tls_id]
            phase_index = int(self._connection.trafficlight.getPhase(tls_id))
            phase_age = float(self._connection.trafficlight.getSpentDuration(tls_id))
            fresh = self._fresh_for(tls_id)
            allowed = controller.allowed_actions(
                phase_index=phase_index, phase_elapsed_s=phase_age, data_fresh=fresh,
                downstream_blocked_by_green=self._statuses.get(tls_id, {}),
                simulation_step_s=self.sumo_step_s,
            )
            requested_index = int(action_values[index])
            if requested_index < 0 or requested_index >= self.action_count or not self._mask[index * self.action_count + requested_index]:
                requested_index = int(np.flatnonzero(self._mask[index * self.action_count:(index + 1) * self.action_count])[0])
                substituted = True
            else:
                substituted = False
            executed = self._action_maps[index].get(requested_index)
            if executed is None:
                executed = next((row for row in allowed if row.kind == "follow_native"), allowed[0])
                substituted = True
            if executed.kind == "hold_all_red":
                held_count += 1
            if executed.kind in {
                "maintain_green", "request_yellow", "extend_green_to_max", "release_green",
                "follow_native", "hold_all_red", "hold_for_confirmation", "prepare_clearance_boundary",
            }:
                controller.apply_action(
                    tls_id=tls_id, traci_trafficlight=self._connection.trafficlight,
                    action=executed, phase_index=phase_index, phase_elapsed_s=phase_age,
                    data_fresh=fresh, downstream_blocked_by_green=self._statuses.get(tls_id, {}),
                    simulation_step_s=self.sumo_step_s, now_s=self._sim_time_s,
                )
            row = {
                "time_s": round(self._sim_time_s, 3), "signal_id": tls_id,
                "requested_action_index": int(action_values[index]),
                "masked_action_index": requested_index,
                "phase_before": phase_index,
                "allowed": [item.key for item in allowed],
                "executed": executed.key,
                "substituted": substituted,
            }
            executed_rows.append(row)
            self._action_stream.write(json.dumps(row, ensure_ascii=False) + "\n")

        steps = int(round(self.decision_period_s / self.sumo_step_s))
        time_loss_vehicle_s = 0.0
        arrivals = 0
        collision_vehicle_steps = 0
        teleported: set[str] = set()
        for _ in range(steps):
            self._connection.simulationStep()
            self._sim_time_s = float(self._connection.simulation.getTime())
            self._trace_phases()
            departed_now = self._connection.simulation.getDepartedIDList()
            self._departed_ids.update(departed_now)
            self._arrived_ids.update(self._connection.simulation.getArrivedIDList())
            arrivals += int(self._connection.simulation.getArrivedNumber())
            teleported.update(self._connection.simulation.getStartingTeleportIDList())
            collision_vehicle_steps += int(self._connection.simulation.getCollidingVehiclesNumber())
            if self.gui and self._gui_view_id is not None:
                for vehicle_id in departed_now:
                    self._connection.vehicle.setColor(vehicle_id, (255, 0, 255, 255))
                active_ids = self._connection.vehicle.getIDList()
                if self._gui_tracked_vehicle not in active_ids:
                    if active_ids:
                        self._gui_tracked_vehicle = str(active_ids[0])
                        self._connection.gui.trackVehicle(self._gui_view_id, self._gui_tracked_vehicle)
                    else:
                        self._gui_tracked_vehicle = None
                if self._gui_tracked_vehicle in active_ids:
                    x, y = self._connection.vehicle.getPosition(self._gui_tracked_vehicle)
                    # trackVehicle alone did not keep the captured viewport centered
                    # reliably in the previous run, so set the view center explicitly.
                    self._connection.gui.setOffset(self._gui_view_id, float(x), float(y))
                if not self._gui_preview_scheduled and self._sim_time_s >= min(300.0, self.end_time_s / 2):
                    self._connection.gui.screenshot(self._gui_view_id, str(self._gui_preview_path))
                    self._gui_preview_scheduled = True
            for vehicle_id in self._connection.vehicle.getIDList():
                allowed_speed = max(0.1, float(self._connection.vehicle.getAllowedSpeed(vehicle_id)))
                speed = max(0.0, float(self._connection.vehicle.getSpeed(vehicle_id)))
                time_loss_vehicle_s += self.sumo_step_s * max(0.0, 1.0 - min(speed / allowed_speed, 1.0))
        self._teleport_ids.update(teleported)
        self._collision_vehicle_count += collision_vehicle_steps
        self._refresh()
        queue_vehicles = sum(int(row.get("queue_vehicle_count", 0)) for row in self._latest_snapshot["lane_states"].values())
        queue_vehicle_s = queue_vehicles * self.decision_period_s
        receiver_full = 0
        for edge_id in self.receiver_edge_ids:
            state = self._latest_snapshot["edge_states"].get(edge_id)
            if state is None:
                continue
            capacity = int(state.get("storage_capacity_vehicles_estimate", 0))
            fraction = int(state.get("vehicle_count", 0)) / capacity if capacity > 0 else 0.0
            if fraction >= 0.85:
                receiver_full += 1
        waiting_long = sum(
            float(self._connection.vehicle.getWaitingTime(vehicle_id)) > 120.0
            for vehicle_id in self._connection.vehicle.getIDList()
        )
        pending_due = self._due_pending()
        controlled = max(1, len(self.signal_ids))
        rewards = {
            "delay": -0.05 * time_loss_vehicle_s,
            "queue": -0.02 * queue_vehicle_s / controlled,
            "receiver_spillback": -0.50 * receiver_full / controlled,
            "throughput": 0.30 * arrivals,
            "excessive_wait": -0.05 * waiting_long / controlled,
            "due_not_inserted": -0.05 * pending_due / controlled,
            "confirmed_full_all_red_hold": -0.10 * held_count,
            "collision": -20.0 * collision_vehicle_steps,
            "teleport": -5.0 * len(teleported),
        }
        reward = float(sum(rewards.values()))
        self._step_count += 1
        for name, value in rewards.items():
            self._reward_totals[name] += float(value)
        reward_row = {
            "step": self._step_count, "time_s": round(self._sim_time_s, 3),
            "reward": reward, "components": rewards,
            "time_loss_vehicle_s": round(time_loss_vehicle_s, 4),
            "queue_vehicle_s_estimated": round(queue_vehicle_s, 4),
            "arrivals": arrivals, "pending_due": pending_due,
            "active_vehicles": int(self._connection.vehicle.getIDCount()),
            "receiver_edges_at_85pct": receiver_full,
            "action_substitutions": sum(row["substituted"] for row in executed_rows),
        }
        self._reward_stream.write(json.dumps(reward_row, ensure_ascii=False) + "\n")
        self._last_executed_actions = executed_rows

        min_expected = int(self._connection.simulation.getMinExpectedNumber())
        terminated = min_expected == 0
        truncated = self._sim_time_s >= self.end_time_s - 1e-9 and not terminated
        info = {
            "time_s": self._sim_time_s,
            "reward_components": rewards,
            "requested_vs_executed": executed_rows,
            "action_mask": self._mask.copy(),
            "active_vehicles": int(self._connection.vehicle.getIDCount()),
            "due_pending_vehicles": pending_due,
            "arrivals_this_interval": arrivals,
            "collisions_vehicle_steps": collision_vehicle_steps,
            "teleported_vehicle_ids": sorted(teleported),
            "terminated_naturally": terminated,
            "truncated_by_horizon": truncated,
            "run_dir": str(self._run_dir),
            "route_file": str(self.routes),
        }
        self._decision_log.append({"time_s": self._sim_time_s, "reward": reward, "components": rewards})
        if terminated or truncated:
            self._natural_terminal = terminated
        self._final_active_count = int(self._connection.vehicle.getIDCount())
        self._final_due_pending_count = pending_due
        return self._observation(), reward, terminated, truncated, info

    def close(self) -> None:
        if self._closed:
            return
        try:
            if self._connection is not None:
                self._final_active_count = int(self._connection.vehicle.getIDCount())
                self._final_due_pending_count = self._due_pending()
            if self._action_stream is not None:
                self._action_stream.flush()
                self._action_stream.close()
            if self._reward_stream is not None:
                self._reward_stream.flush()
                self._reward_stream.close()
            if self._phase_stream is not None:
                self._phase_stream.flush()
                self._phase_stream.close()
            if self._connection is not None:
                # SUMO-GUI remains open at the final frame unless explicitly told
                # to quit; do not block the evaluator waiting for the user to close it.
                self._connection.close(wait=True)
        finally:
            if self._stdout is not None:
                self._stdout.flush()
                self._stdout.close()
            self._closed = True
            if self._run_dir is not None:
                write_json(self._run_dir / "episode_summary.json", {
                    "run_id": self._run_dir.name,
                    "steps": self._step_count,
                    "simulation_time_s": self._sim_time_s,
                    "seed": self._seed,
                    "departed": len(self._departed_ids),
                    "arrived": len(self._arrived_ids),
                    "active_at_end": self._final_active_count,
                    "due_pending_at_end": self._final_due_pending_count,
                    "teleport_ids": sorted(self._teleport_ids),
                    "collision_vehicle_steps": self._collision_vehicle_count,
                    "reward_totals": dict(self._reward_totals),
                    "natural_terminal": self._natural_terminal,
                    "horizon_truncated": self._sim_time_s >= self.end_time_s - 1e-9 and not self._natural_terminal,
                    "action_substitutions": sum(
                        bool(json.loads(line).get("substituted"))
                        for line in (self._run_dir / "actions.jsonl").read_text(encoding="utf-8").splitlines()
                        if line.strip()
                    ),
                    "phase_trace_rows": sum(
                        1 for line in (self._run_dir / "phase_trace.jsonl").read_text(encoding="utf-8").splitlines()
                        if line.strip()
                    ),
                    "scope_limit": "Gym integration diagnostic; no PPO weights updated by this environment itself.",
                })

    def _trace_phases(self) -> None:
        """Record actual SUMO state changes at the physical 0.2 s cadence."""
        if self._connection is None or self._phase_stream is None:
            return
        now = float(self._connection.simulation.getTime())
        for tls_id in self.signal_ids:
            phase = int(self._connection.trafficlight.getPhase(tls_id))
            state = str(self._connection.trafficlight.getRedYellowGreenState(tls_id))
            if self._phase_index.get(tls_id) != phase or self._phase_state.get(tls_id) != state:
                row = {
                    "time_s": round(now, 3),
                    "signal_id": tls_id,
                    "from_phase": self._phase_index.get(tls_id),
                    "phase_index": phase,
                    "phase_state": state,
                    "source": "SUMO TraCI; sampled after each physical step",
                }
                self._phase_stream.write(json.dumps(row, ensure_ascii=False) + "\n")
                self._phase_index[tls_id] = phase
                self._phase_state[tls_id] = state
